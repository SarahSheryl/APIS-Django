
from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import (
    MeatViewSet, MeatVarietiesCreateAPIView, MeatVarietiesDestroyAPIView
)

router = DefaultRouter(trailing_slash=False)
router.register('meat', MeatViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('meat/<slug:meat_slug>/variety', MeatVarietiesCreateAPIView.as_view()),
    path('meat/<slug:meat_slug>/variety/<slug:variety_slug>', MeatVarietiesDestroyAPIView.as_view()),
]
