 
from django.db import models
from colorfield.fields import ColorField

# Create your models here.
class Meat(models.Model):
    meat_name = models.TextField(unique=True)
    color = ColorField(default='#FF0000')

    class Meta:
     
        ordering = ['-id']
        db_table = 'Meat'
        verbose_name_plural = "Meat"

    def __str__(self):
        return self.meat_name

class MeatVarieties(models.Model):
    meat = models.ForeignKey('Meat', related_name='varieties', on_delete=models.CASCADE)
    variety = models.TextField()

    class Meta:
       # Comment out managed = False when changing schema
        #managed = False 
        ordering = ['-id']
        db_table = 'meat_varieties'
        verbose_name_plural = "meat varieties"

    def __str__(self):
        return f"{self.meat.meat_name} {self.variety}"
