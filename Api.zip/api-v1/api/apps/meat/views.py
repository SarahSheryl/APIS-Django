
from django.shortcuts import render

# Create your views here.

from rest_framework import generics, mixins, status, viewsets
from rest_framework.exceptions import NotFound
from rest_framework.permissions import (
    AllowAny, IsAdminUser
)
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Meat, MeatVarieties
from api.apps.core.permissions import IsAdminUserOrReadOnly
from .renderers import MeatJSONRenderer, MeatVarietiesJSONRenderer
from .serializers import MeatSerializer, MeatVarietiesSerializer

#from .schemas import (FruitsSchema, FruitVarietiesSchema)

class MeatViewSet(mixins.CreateModelMixin,
                     mixins.ListModelMixin,
                     mixins.RetrieveModelMixin,
                     mixins.DestroyModelMixin,
                     viewsets.GenericViewSet):
 
   # schema = FruitsSchema()
    lookup_field = 'meat_slug'
    queryset = Meat.objects.all()
    permission_classes = (IsAdminUserOrReadOnly,)
    renderer_classes = (MeatJSONRenderer,)
    serializer_class = MeatSerializer

    def get_queryset(self):
        queryset = self.queryset
        meat_slug = self.request.query_params.get('meat_slug', None)
        if meat_slug is not None:
            meat_name = meat_slug.replace('-', ' ')
            if meat_name is not None:
                queryset = queryset.filter(meat_name=meat_name)
        return queryset

    def create(self, request):
        serializer_context = {
            'request': request
        }
        serializer_data = request.data.get('meat', {})
        varieties = serializer_data.pop('varieties', None)
        print(varieties)
        if not varieties:
            raise NotFound('Atleast one variety has to be included.')

        if not all(isinstance(item, str) for item in varieties):
            raise NotFound('All varieties have to be strings')

        serializer_context['varieties'] = varieties
        serializer = self.serializer_class(
            data=serializer_data, context=serializer_context
        )

        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def list(self, request):
        serializer_context = {'request': request}
        data = Meat.objects.all()

        serializer = self.serializer_class(
            data,
            context=serializer_context,
            many=True
        )
        print(serializer.data)
        return Response({
            'results': serializer.data,
            'count': data.count()
        })

    def retrieve(self, request, meat_slug=None):
        serializer_context = {'request': request}
        meat_name = meat_slug.replace('-', ' ')
        try:
            serializer_instance = self.queryset.get(meat_name=meat_name)
        except Meat.DoesNotExist:
            raise NotFound('A Meat with this name does not exist.')

        serializer = self.serializer_class(
            serializer_instance,
            context=serializer_context
        )

        return Response(serializer.data, status=status.HTTP_200_OK)


    def update(self, request, meat_slug=None):
        serializer_context = {'request': request}

        meat_name = meat_slug.replace('-', ' ')
        try:
            serializer_instance = self.queryset.get(meat_name=meat_name)
        except Meat.DoesNotExist:
            raise NotFound('A meat with this name does not exist.')

        serializer_data = request.data.get('meat', {})

        serializer = self.serializer_class(
            serializer_instance,
            context=serializer_context,
            data=serializer_data,
            partial=True
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data, status=status.HTTP_200_OK)

    def destroy(self, request, meat_slug=None):
        meat_name = meat_slug.replace('-', ' ')
        try:
            meat = Meat.objects.get(meat_name=meat_name)
        except Meat.DoesNotExist:
            raise NotFound('A Meat with this name does not exist.')

        meat.delete()

        return Response(None, status=status.HTTP_204_NO_CONTENT)


class MeatVarietiesCreateAPIView(generics.CreateAPIView):
  
    #schema = FruitVarietiesSchema()
    lookup_field = 'variety_slug'
    permission_classes = (IsAdminUserOrReadOnly,)
    queryset = MeatVarieties.objects.select_related('meat')
    renderer_classes = (MeatVarietiesJSONRenderer,)
    serializer_class = MeatVarietiesSerializer

    def create(self, request, meat_slug=None):

        data = request.data.get('meat', {})
        meat_name = meat_slug.replace('-', ' ')
        context = {}
        try:
            context['meat'] = meat.objects.get(meat_name=meat_name)
        except Meat.DoesNotExist:
            raise NotFound('A Meat with this name does not exist.')

        serializer = self.serializer_class(data=data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data, status=status.HTTP_201_CREATED)

class MeatVarietiesDestroyAPIView(generics.DestroyAPIView):
    
    lookup_field = 'variety_slug'
    #schema = FruitVarietiesSchema()
    permission_classes = (IsAdminUser,)
    queryset = MeatVarieties.objects.all()

    def destroy(self, request, meat_slug=None, variety_slug=None):
        variety_name = variety_slug.replace('-', ' ')

        try:
            variety = MeatVarieties.objects.get(variety=variety_name)
        except MeatVarieties.DoesNotExist:
            raise NotFound('A Meat with this variety does not exist.')
        variety.delete()

        return Response(None, status=status.HTTP_204_NO_CONTENT)

