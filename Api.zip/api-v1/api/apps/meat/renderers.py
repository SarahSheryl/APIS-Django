from api.apps.core.renderers import ApiJSONRenderer


class MeatJSONRenderer(ApiJSONRenderer):
    object_label = 'meats'
    pagination_object_label = 'meats'
    pagination_count_label = 'meats_count'

class MeatVarietiesJSONRenderer(ApiJSONRenderer):
    object_label = 'meat_varieties'
    pagination_object_label = 'meat varieties'
    pagination_count_label = 'meat variety count'