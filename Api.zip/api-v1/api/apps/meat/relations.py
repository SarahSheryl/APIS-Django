from rest_framework import serializers

from .models import Meat, MeatVarieties

class MeatVarietiesRelatedField(serializers.RelatedField):
    def get_queryset(self):
        return MeatVarieties.objects.all()

    def to_internal_value(self,data):
        try:
            return MeatVarieties.objects.filter(id=data)
        except MeatVarieties.DoesNotExist:
            raise serializers.ValidationError(
                'Meat with the specified variety does not exist.'
            )

    def to_representation(self, value):
        #print(value.fruit)
        return value.variety


class MeatRelatedField(serializers.RelatedField):
    def get_queryset(self):
        return Meat.objects.all()

    def to_internal_value(self,data):
        try:
            return Meat.objects.get(meat_name=data)
        except Meat.DoesNotExist:
            raise serializers.ValidationError(
                'Fruit with the specified variety does not exist.'
            )

    def to_representation(self, value):
        return value.meat_name

  
