from rest_framework import serializers 
from .models import Meat, MeatVarieties
from django.utils.text import slugify

class MeatVarietiesSerializer(serializers.ModelSerializer):

    class Meta:
        model = MeatVarieties
        fields = (
                    'variety',
                )
    
    def create(self, validated_data):
        meat = self.context['meat']
        return MeatVarieties.objects.create(
           meat=meat, **validated_data)

    def to_representation(self, obj):
        return obj.variety



class MeatSerializer(serializers.ModelSerializer):
    varieties = MeatVarietiesSerializer(many=True, read_only=True)
    meat_slug = serializers.SerializerMethodField(read_only=True)

    def get_meat_slug(self, instance):
        return slugify(instance.meat_name).upper()

    class Meta:
        model = Meat
        fields = (
                    'meat_name',
                    'color',
                    'meat_slug',
                    'varieties',
                )

    def create(self, validated_data):
        varieties = self.context['varieties']
        meat = meat.objects.create(**validated_data)
        for variety in varieties:
            MeatVarieties.objects.create(meat=meat, variety=variety)
        return meat

    