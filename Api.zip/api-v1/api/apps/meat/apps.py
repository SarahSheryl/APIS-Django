from django.apps import AppConfig


class MeatConfig(AppConfig):
    name = 'api.apps.meat'
