from rest_framework import serializers
from .models import Devices,QScanMeat,Customization
from api.apps.warehouses.relations import WarehousesRelatedField
from api.apps.fruits.relations import FruitVarietiesRelatedField, FruitRelatedField
from api.apps.meat.relations import MeatVarietiesRelatedField, MeatRelatedField
from api.apps.device_types.relations import DeviceTypesRelatedField
from api.apps.vendor.relations import VendorRelatedField
from api.apps.fruits.serializers import FruitsSerializer
from api.apps.warehouses.relations import WarehousesRelatedField
from api.apps.device_types.relations import DeviceTypesRelatedField



class DevicesSerializer(serializers.ModelSerializer):
    fruit_variety = FruitVarietiesRelatedField(many=False, required=False)
    fruit = serializers.CharField(source='fruit_variety.fruit.fruit_name',read_only=True)
    warehouse = WarehousesRelatedField(read_only=True)
    device_type = DeviceTypesRelatedField(many=False, required=True)
    vendor_code = VendorRelatedField(many=False,required=True)

    class Meta:
        model = Devices
        fields = (
            'id',
            'warehouse',
            'device_id',
            'device_type',
            'fruit',
            'fruit_variety',
            'batch_number',
            'vendor_code',
            'white_standard',
        )

    def create(self, validated_data):
        return Devices.objects.create(**validated_data)

class QScanDevicesSerializer(serializers.ModelSerializer):
    meat_variety = MeatVarietiesRelatedField(many=False, required=False)
  
    warehouse = WarehousesRelatedField(read_only=True)
    device_type = DeviceTypesRelatedField(many=False, required=True)
    vendor_code = VendorRelatedField(many=False,required=True)

    class Meta:
        model = QScanMeat
        fields = (
            'id',
            'warehouse',
            'device_id',
            'device_type',
        
            'meat_variety',
            'batch_number',
            'vendor_code'
        )

    def create(self, validated_data):
        return Devices.objects.create(**validated_data)

"""
    def get_fruit_name(self, obj):
        return obj.fruit_variety.fruit.fruit_name
"""

class CustomizationSerializer(serializers.ModelSerializer):
    fruit = serializers.CharField(source='fruitvariety.fruit.fruit_name',read_only=True)
    color = serializers.CharField(source='fruitvariety.fruit.color',read_only=True)
    warehouse = serializers.IntegerField(source='device.warehouse.id',read_only=True)
    user = serializers.ReadOnlyField(source='device.warehouse.user_id',read_only=True)
    fruitvariety=FruitVarietiesRelatedField(many=False, required=False)
    fruitvariety_name = serializers.CharField(source='fruitvariety.variety',read_only=True)
    class Meta:
        model = Customization
        fields =(
            'id',
            'device',
            'warehouse',
            'user',
            'fruit',
            'fruitvariety',
            'color',
            'fruitvariety_name'
        )