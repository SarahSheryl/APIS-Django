from api.apps.core.renderers import ApiJSONRenderer

class DevicesJSONRenderer(ApiJSONRenderer):
    object_label = 'devices'
    pagination_object_label = 'devices'
    pagination_count_label = 'devices_count'