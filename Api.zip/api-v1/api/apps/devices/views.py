from rest_framework import generics, mixins, status, viewsets
from rest_framework.exceptions import NotFound
from rest_framework.permissions import (
    AllowAny,IsAuthenticated, IsAuthenticatedOrReadOnly
)
from rest_framework.response import Response


from .models import Devices,QScanMeat,Customization
from api.apps.warehouses.models import Warehouses
from api.apps.fruits.models import FruitVarieties
from api.apps.device_types.models import DeviceTypes
from .renderers import DevicesJSONRenderer
from .serializers import DevicesSerializer,QScanDevicesSerializer
from .serializers import CustomizationSerializer
from .schemas import DevicesSchema


class DevicesViewSet(mixins.CreateModelMixin,
                     mixins.ListModelMixin,
                     mixins.RetrieveModelMixin,
                     mixins.DestroyModelMixin,
                     viewsets.GenericViewSet):
    """
    create:
    Create a new device.

    list:
    Return a list of all the devices.

    retrieve:
    Return the given device.

    update:
    Update the given device with new attributes.

    destroy:
    Delete the given device.

    """
    schema = DevicesSchema()
    lookup_field = 'device_id'
    queryset = Devices.objects.select_related('warehouse', 'warehouse__user')
    permission_classes = (IsAuthenticated,)
    renderer_classes = (DevicesJSONRenderer,)
    serializer_class = DevicesSerializer

    def get_queryset(self):
        queryset = self.queryset
        if not self.request.user.is_superuser:
            queryset = self.queryset.filter(user=self.request.user)
        device_id = self.request.query_params.get('device_id', None)
        if device_id is not None:
            queryset = queryset.filter(device_id=device_id)
        return queryset

    def create(self, request):
        serializer_data = request.data.get('device', {})
        serializer_context = {}
        serializer = self.serializer_class(
            data=serializer_data,
            context=serializer_context
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def list(self, request):
        queryset = self.filter_queryset(self.get_queryset())

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.serializer_class(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    def retrieve(self, request, device_id=None):
        serializer_context = {'request': request}

        try:
            serializer_instance = self.queryset.get(device_id=device_id)
        except Devices.DoesNotExist:
            raise NotFound('A device with this device id does not exist.')

        serializer = self.serializer_class(
            serializer_instance,
            context=serializer_context
        )

        return Response(serializer.data, status=status.HTTP_200_OK)

    def update(self, request, device_id=None):
        serializer_context = {
            'request': request
        }

        try:
            serializer_instance = self.queryset.get(device_id=device_id)
        except Devices.DoesNotExist:
            raise NotFound('A device with this device id does not exist.')

        serializer_data = request.data.get('device', {})

        variety = serializer_data.pop('variety', None)
        if variety:
            try:
                serializer_data['fruit_variety'] = FruitVarieties.objects.get(
                    variety=variety).id
            except FruitVarieties.DoesNotExist:
                raise NotFound('A fruit with this variety does not exist.')

        warehouse_id = serializer_data.pop('warehouse_id', None)
        if warehouse_id:
            try:
                serializer_data['warehouse'] = Warehouses.objects.get(
                    warehouse_id=warehouse_id)
            except Warehouses.DoesNotExist:
                raise NotFound(
                    'A warehouse with this warehouse_id does not exist.')

        serializer = self.serializer_class(
            serializer_instance,
            context=serializer_context,
            data=serializer_data,
            partial=True
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data, status=status.HTTP_200_OK)

    def destroy(self, request, device_id=None):
        try:
            device = Devices.objects.get(device_id=device_id)
        except Devices.DoesNotExist:
            raise NotFound('A device with this device id does not exist.')

        device.delete()

        return Response(None, status=status.HTTP_204_NO_CONTENT)

class DevicesDataRetrieveUpdateAPIView(generics.RetrieveUpdateAPIView):
    queryset = Devices.objects.select_related('warehouse', 'warehouse__user')
    permission_classes = (AllowAny,)
    renderer_classes = (DevicesJSONRenderer,)
    serializer_class = DevicesSerializer



class DeviceDataListAPIView(generics.ListCreateAPIView):
    queryset = Devices.objects.select_related('warehouse', 'warehouse__user')
    permission_classes = (AllowAny,)
    renderer_classes = (DevicesJSONRenderer,)
    serializer_class = DevicesSerializer

    def get_queryset(self):
        queryset = self.queryset
        if not self.request.user.is_superuser:
            try:
                warehouse = Warehouses.objects.get(user=self.request.user)
            except Warehouses.DoesNotExist:
                return Devices.objects.none()
            queryset=queryset.filter(warehouse_id=warehouse.id)
        else:
            warehouse_id = self.request.query_params.get('warehouse_id', None)
            if warehouse_id is not None:
                queryset = queryset.filter(warehouse_id=warehouse_id)
        return queryset

class QscanMeatDeviceDataRetrieveUpdateAPIView(generics.RetrieveUpdateAPIView):
    queryset = QScanMeat.objects.select_related('warehouse', 'warehouse__user')
    permission_classes = (AllowAny,)
    renderer_classes = (DevicesJSONRenderer,)
    serializer_class = QScanDevicesSerializer



class QscanMeatDeviceDataListAPIView(generics.ListCreateAPIView):
    schema = DevicesSchema()
    queryset = QScanMeat.objects.select_related('warehouse', 'warehouse__user')
    permission_classes = (AllowAny,)
    renderer_classes = (DevicesJSONRenderer,)
    serializer_class = QScanDevicesSerializer

    def get_queryset(self):
        queryset = self.queryset
        if not self.request.user.is_superuser:
            try:
                warehouse = Warehouses.objects.get(user=self.request.user)
            except Warehouses.DoesNotExist:
                return QScanMeat.objects.none()
            queryset=queryset.filter(warehouse_id=warehouse.id)
        else:
            warehouse_id = self.request.query_params.get('warehouse_id', None)
            if warehouse_id is not None:
                queryset = queryset.filter(warehouse_id=warehouse_id)
        return queryset

        


class CustomizationFruitListAPIView(generics.ListCreateAPIView):
    queryset = Customization.objects.order_by('fruitvariety_id').distinct('fruitvariety')
    #queryset = Customization.objects.all()
    permission_classes = (AllowAny,)
    serializer_class = CustomizationSerializer

    def get_queryset(self):
        list1 = []
        queryset = self.queryset
        if not self.request.user.is_superuser:
            try:
                print(self.request)
                warehouse = Warehouses.objects.get(user=self.request.user)
                #print(self.request.body)
            except Warehouses.DoesNotExist:
                return Customization.objects.none()
            queryset=queryset.filter(device__warehouse__id=warehouse.id)
        else:
            warehouse_id = self.request.query_params.get('warehouse_id', None)
            if warehouse_id is not None:
                queryset = queryset.filter(warehouse_id =warehouse_id)
           # print(queryset)
           
        return queryset

class CustomizationDataRetriveUpdateAPIView(generics.RetrieveUpdateAPIView):
    queryset = Customization.objects.select_related('device__warehouse','device__warehouse__user')
    permission_classes = (AllowAny,)
    serializer_class = CustomizationSerializer