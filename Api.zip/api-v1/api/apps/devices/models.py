from django.db import models
from django.contrib.postgres.fields import JSONField

class Devices(models.Model):
    warehouse = models.ForeignKey('warehouses.Warehouses', null = True, on_delete=models.DO_NOTHING)
    device_type = models.ForeignKey('device_types.DeviceTypes', on_delete=models.PROTECT)
    device_id = models.TextField(unique=True)
    fruit_variety = models.ForeignKey('fruits.FruitVarieties', related_name='fruit_variety', null = True,on_delete=models.SET_NULL)
    batch_number = models.TextField()
    vendor_code = models.ForeignKey('vendor.Vendor', null = True,blank = True,on_delete=models.DO_NOTHING)
    white_standard = models.TextField(null=True,blank=True)
    mac_id = models.TextField(blank=True, null=True)

    class Meta:
        ordering = ['-id']
        # Comment out managed = False when changing schema
        # managed = False
        db_table = 'devices'
        verbose_name_plural = 'devices'

    def __str__(self):
        return f"{self.warehouse.warehouse_id} {self.device_id} {self.device_type}"
 

class QScanMeat(models.Model):
    warehouse = models.ForeignKey('warehouses.Warehouses', null = True, on_delete=models.SET_NULL)
    device_type = models.ForeignKey('device_types.DeviceTypes', on_delete=models.PROTECT)
    device_id = models.TextField(unique=True)
    meat_variety = models.ForeignKey('meat.MeatVarieties', related_name='meat_variety', null = True,on_delete=models.SET_NULL)
    batch_number = models.TextField()
    vendor_code = models.ForeignKey('vendor.Vendor',related_name='vendor_id',null = True,blank = True,on_delete=models.DO_NOTHING)
    mac_id = models.TextField(blank=True, null=True)
    warehouse_name = models.TextField(blank=True, null=True)
    class Meta:
        ordering = ['-id']
  
    def __str__(self):
        return f"{self.warehouse.warehouse_id} {self.device_id} {self.device_type}"


class QLogMeat(models.Model):
    warehouse = models.ForeignKey('warehouses.Warehouses', null = True, on_delete=models.SET_NULL)
    device_type = models.ForeignKey('device_types.DeviceTypes', on_delete=models.PROTECT)
    device_id = models.TextField(unique=True)
    batch_number = models.TextField()
    vendor_code = models.TextField()
    mac_id = models.TextField(blank=True, null=True)
    warehouse_name = models.TextField(blank=True, null=True)
    class Meta:
        ordering = ['-id']
  
    def __str__(self):
        return f"{self.warehouse.warehouse_id} {self.device_id} {self.device_type}"




class Customization(models.Model):
    id = models.AutoField(primary_key=True)
    device = models.ForeignKey('devices.Devices',null=True,blank=True,on_delete=models.CASCADE)
    fruitvariety = models.ForeignKey('fruits.FruitVarieties',null = True,on_delete=models.CASCADE)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return f"{self.device} {self.fruitvariety_id}"




