from rest_framework.schemas import AutoSchema

import coreapi
import coreschema
import json

class DevicesSchema(AutoSchema):

    def get_serializer_fields(self, path, method):
        return []

    def get_manual_fields(self, path, method):
        custom_fields = []
        if "{device_id}" in path:
            custom_fields.append(
                coreapi.Field(
                    "device_id",
                    required=True,
                    location="path",
                    schema=coreschema.Object(description='device id of device'),
                ),
            )

        if method.upper() in ['POST', 'PUT']:
            data =  {
                "device": {
                    "warehouse_id": "required",
                    "device_id": "required",
                    "device_type": "required",
                    "fruit_variety": "optional",
                    "batch_number": "required",
                    "vendor_code": "required",
                    "white_standard": {"required": "required"}
                }
            }

            if method.upper() == "PUT":
                data['device'] = dict.fromkeys(data['device'], 'optional')

            custom_fields.append(
                coreapi.Field(
                    "device",
                    required=True,
                    location="body",
                    schema=coreschema.Object(description=
                        '<pre>'+json.dumps(data, indent=4)+'</pre>')
                ),
            )

        return self._manual_fields + custom_fields