from django.urls import include, path

from rest_framework.routers import DefaultRouter

from .views import (DevicesViewSet,DeviceDataListAPIView,DevicesDataRetrieveUpdateAPIView,QscanMeatDeviceDataRetrieveUpdateAPIView,QscanMeatDeviceDataListAPIView,CustomizationDataRetriveUpdateAPIView,CustomizationFruitListAPIView,)

router = DefaultRouter(trailing_slash=False)
router.register('devices', DevicesViewSet)

urlpatterns = [
     path('', include(router.urls)),
     path('device/<int:pk>',DevicesDataRetrieveUpdateAPIView.as_view()),
     path('devices-list/',DeviceDataListAPIView.as_view()),
     path('qscanmeatdevices/<int:pk>',QscanMeatDeviceDataRetrieveUpdateAPIView.as_view()),
     path('qscanmeatdevices-list/',QscanMeatDeviceDataListAPIView.as_view()),
     path('customization/<int:pk>',CustomizationDataRetriveUpdateAPIView.as_view()),
     path('fruits-list/',CustomizationFruitListAPIView.as_view())
]
