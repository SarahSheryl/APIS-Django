from django.urls import include, path

from rest_framework.routers import DefaultRouter

from .views import (QLogDataViewSet, QLogDataHeadersRetrieveAPIView,QLogMeatDataViewSet,QLogMeatDataHeadersRetrieveAPIView,QLogGPSViewSet,QLogGPSHeadersRetrieveAPIView)

router = DefaultRouter(trailing_slash=False)
router.register('QLog-data', QLogDataViewSet)
router.register('QLogMeat-data',QLogMeatDataViewSet)
router.register('QLogGPS-data',QLogGPSViewSet)

urlpatterns = [
     path('', include(router.urls)),
     path('QLog-data/headers', QLogDataHeadersRetrieveAPIView.as_view()),
     path('QLogMeat-data/headers', QLogMeatDataHeadersRetrieveAPIView.as_view()),
     path('QLogGPS-data/headers', QLogGPSHeadersRetrieveAPIView.as_view()),

]
