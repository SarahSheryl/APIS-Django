from django.shortcuts import render

# Create your views here.
from rest_framework import generics, mixins, status, viewsets
from rest_framework.exceptions import NotFound
from rest_framework.permissions import (
    AllowAny, IsAuthenticated
)
from rest_framework.response import Response
from django.db.models.functions import Concat
from .models import QLogData,Meat,gps_qlog
from api.apps.warehouses.models import Warehouses
from api.apps.devices.models import Devices
from .renderers import QLogDataJSONRenderer, QLogDataHeadersJSONRenderer
from .serializers import QLogDataSerializer,QLogMeatDataSerializer,QLogGPSDataSerializer
from rest_framework.viewsets import ReadOnlyModelViewSet


class QLogDataViewSet(mixins.ListModelMixin,
                           viewsets.GenericViewSet):
    """
    list:
    Return a list of all the warehouse data with given offset and limit.

    """

    queryset = QLogData.objects.select_related('device')
    permission_classes = (AllowAny,)
    renderer_classes = (QLogDataJSONRenderer,)
    serializer_class = QLogDataSerializer

    def get_queryset(self):
        queryset = self.queryset
        if not self.request.user.is_superuser:
            try:
                warehouse = Warehouses.objects.get(user=self.request.user)
            except Warehouses.DoesNotExist:
                return QLogData.objects.none()
            queryset = queryset.filter(warehouse_id=warehouse.warehouse_id)
        else:
            warehouse_id = self.request.query_params.get('warehouse_id', None)
            if warehouse_id is not None:
                queryset = queryset.filter(warehouse_id=warehouse_id)

        device = self.request.query_params.get('device', None)
        if device is not None:
            queryset = queryset.filter(device=device)

        start = self.request.query_params.get('start', None)
        end = self.request.query_params.get('end', None)
        if start is not None and end is not None:
            queryset = queryset.annotate(timedate=Concat('date','timestamp'))
            """ creates a virtual column timedate with time and date in it -- date and time filter"""
            queryset = queryset.filter(timedate__range=(start, end))

        return queryset

    def list(self, request):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.serializer_class(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

class QLogDataHeadersRetrieveAPIView(generics.RetrieveAPIView):
    """
    get:
    Return a list of all headers of table.

    """
    permission_classes = (AllowAny,)
    renderer_classes = (QLogDataHeadersJSONRenderer,)
    pagination_class = None

    def retrieve(self, request):
        labels = {}

        for field in QLogDataSerializer.Meta.model._meta.get_fields():
            if field.name in QLogDataSerializer.Meta.fields:
                labels[field.name] = field.verbose_name

        for field in QLogDataSerializer.Meta.fields:
            if labels.get(field, None) is None:
                labels[field] = field

        return Response({'results': labels})


class QLogMeatDataViewSet(mixins.ListModelMixin,
                           viewsets.GenericViewSet):
    """
    list:
    Return a list of all the warehouse data with given offset and limit.

    """

    queryset = Meat.objects.all()
    permission_classes = (AllowAny,)
    renderer_classes = (QLogDataJSONRenderer,)
    serializer_class = QLogMeatDataSerializer

    def get_queryset(self):
        queryset = self.queryset
        if not self.request.user.is_superuser:
            try:
                warehouse = Warehouses.objects.get(user=self.request.user)
            except Warehouses.DoesNotExist:
                return QLogData.objects.none()
            queryset = queryset.filter(warehouse_id=warehouse.warehouse_id)
        else:
            warehouse_id = self.request.query_params.get('warehouse_id', None)
            if warehouse_id is not None:
                queryset = queryset.filter(warehouse_id=warehouse_id)

        device = self.request.query_params.get('device', None)
        if device is not None:
            queryset = queryset.filter(device=device)

        start = self.request.query_params.get('start', None)
        end = self.request.query_params.get('end', None)
        if start is not None and end is not None:
            queryset = queryset.annotate(timedate=Concat('date','timestamp'))
            """ creates a virtual column timedate with time and date in it -- date and time filter"""
            queryset = queryset.filter(timedate__range=(start, end))

        return queryset

    def list(self, request):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.serializer_class(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

class QLogMeatDataHeadersRetrieveAPIView(generics.RetrieveAPIView):
    """
    get:
    Return a list of all headers of table.

    """
    permission_classes = (AllowAny,)
    renderer_classes = (QLogDataHeadersJSONRenderer,)
    pagination_class = None

    def retrieve(self, request):
        labels = {}
    
        for field in QLogMeatDataSerializer.Meta.model._meta.get_fields():
            if field.name in QLogMeatDataSerializer.Meta.fields:
                labels[field.name] = field.verbose_name

        for field in QLogMeatDataSerializer.Meta.fields:
            if labels.get(field, None) is None:
                labels[field] = field

        return Response({'results': labels})



class QLogGPSViewSet(mixins.ListModelMixin,
                           viewsets.GenericViewSet):
    """
    list:
    Return a list of all the warehouse data with given offset and limit.

    """

    queryset = gps_qlog.objects.all()
    permission_classes = (AllowAny,)
    renderer_classes = (QLogDataJSONRenderer,)
    serializer_class = QLogGPSDataSerializer

    def get_queryset(self):
        queryset = self.queryset
        if not self.request.user.is_superuser:
            try:
                warehouse = Warehouses.objects.get(user=self.request.user)
            except Warehouses.DoesNotExist:
                return gps_qlog.objects.none()
            queryset = queryset.filter(warehouse_id=warehouse.warehouse_id)
        else:
            warehouse_id = self.request.query_params.get('warehouse_id', None)
            if warehouse_id is not None:
                queryset = queryset.filter(warehouse_id=warehouse_id)

        device = self.request.query_params.get('device', None)
        if device is not None:
            queryset = queryset.filter(device=device)

        start = self.request.query_params.get('start', None)
        end = self.request.query_params.get('end', None)
        if start is not None and end is not None:
            queryset = queryset.annotate(timedate=Concat('date','timestamp'))
            """ creates a virtual column timedate with time and date in it -- date and time filter"""
            queryset = queryset.filter(timedate__range=(start, end))

        return queryset

    def list(self, request):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.serializer_class(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

class QLogGPSHeadersRetrieveAPIView(generics.RetrieveAPIView):
    """
    get:
    Return a list of all headers of table.

    """
    permission_classes = (AllowAny,)
    renderer_classes = (QLogDataHeadersJSONRenderer,)
    pagination_class = None

    def retrieve(self, request):
        labels = {}

        for field in QLogGPSDataSerializer.Meta.model._meta.get_fields():
            if field.name in QLogGPSDataSerializer.Meta.fields:
                labels[field.name] = field.verbose_name

        for field in QLogGPSDataSerializer.Meta.fields:
            if labels.get(field, None) is None:
                labels[field] = field

        return Response({'results': labels})