from django.apps import AppConfig


class QlogConfig(AppConfig):
    name = 'api.apps.qlog'
