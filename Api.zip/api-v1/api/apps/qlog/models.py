from django.db import models
import uuid

# Create your models here.


# TMP_Temperature [°C], [°C], BME pressure [hPa], BME raw relative humidity [%], BME gas [Ohm], BME IAQ, BME IAQ accuracy, BME temperature [°C], BME relative humidity [%], BME Static IAQ, 
# BME CO2 equivalent, BME breath VOC equivalent, SCD41 temperature, SCD41 humidity, SCD41 CO2,
#  SGP40 RAW, SGP40 VOC INDEX, ZMOD4410 ETOH, ZMOD4410 TVOC, ZMOD4410 eCO2,
#  ZMOD4410 IAQ, ZMOD4450 RAQ, SEEED_O2 [%]
class QLogData(models.Model):
    uuid = models.UUIDField(primary_key = True, default = uuid.uuid4,editable = False)
    warehouse_id = models.TextField(blank=True, null=True)
    timestamp = models.TextField(blank=True, null=True, verbose_name='time')
    date = models.TextField(blank=True, null=True)
    device = models.ForeignKey("devices.Devices", blank=True, null=True, on_delete=models.DO_NOTHING, to_field="device_id")
    temperature = models.FloatField(blank=True, null=True)
    humidity = models.FloatField(blank=True, null=True)
    gas1 = models.FloatField(blank=True, null=True)
    gas2 = models.FloatField(blank=True, null=True)
    gas3 = models.FloatField(blank=True, null=True)
    gas4 = models.FloatField(blank=True, null=True)
    gas5 = models.FloatField(blank=True, null=True)
    mac_id = models.TextField(blank=True, null=True)
    tmp_temp = models.FloatField(blank=True, null=True,verbose_name='temperature')
    bme_raw_temp =models.FloatField(blank=True, null=True)
    bme_pressure = models.FloatField(blank=True,null=True)
    bme_raw_rel_humidity =  models.FloatField(blank=True,null=True)
    bme_gas = models.FloatField(blank=True,null=True)
    bme_iaq =  models.FloatField(blank=True,null=True)
    bme_iaq_acc = models.FloatField(blank=True,null=True)
    bme_temp=  models.FloatField(blank=True,null=True)
    bme_rel_humidity = models.FloatField(blank=True,null=True,verbose_name='humidity')
    bme_static_iaq =  models.FloatField(blank=True,null=True)
    bme_co2_equiv = models.FloatField(blank=True,null=True)
    bme_breath_voc_equiv =  models.FloatField(blank=True,null=True)
    scd41_temp = models.FloatField(blank=True,null=True)
    scd41_humidity = models.FloatField(blank=True,null=True)
    scd41_co2 = models.FloatField(blank=True,null=True,verbose_name='co2')
    sgp40_raw = models.FloatField(blank=True,null=True)
    sgp40_voc = models.FloatField(blank=True,null=True)
    sgp40_voc_index = models.FloatField(blank=True,null=True)
    zmod4410_etoh = models.FloatField(blank=True,null=True)
    zmod4410_tvoc = models.FloatField(blank=True,null=True)
    zmod4410_eco2 = models.FloatField(blank=True,null=True)
    zmod4410_iaq = models.FloatField(blank=True,null=True)
    zmod4450_raq = models.FloatField(blank=True,null=True)
    seeed_02 = models.FloatField(blank=True,null=True)
    class Meta:
        ordering = ['-date','-timestamp']
        db_table = 'QLog_data'

    def __str__(self):
        return f"{self.id}_{self.device}"

class Meat(models.Model):
    uuid = models.UUIDField(primary_key = True, default = uuid.uuid4,editable = False)
    warehouse_id = models.TextField(blank=True, null=True)
    timestamp = models.TextField(blank=True, null=True, verbose_name='time')
    date = models.TextField(blank=True, null=True)
    device = models.TextField(blank=True, null=True)
    temperature = models.FloatField(blank=True, null=True)
    humidity = models.FloatField(blank=True, null=True)
    voc = models.FloatField(blank=True, null=True)
    carbondioxide = models.FloatField(blank=True, null=True)
    hydrogensulphide = models.FloatField(blank=True, null=True)
    ammonia = models.FloatField(blank=True, null=True)
    oxygen = models.FloatField(blank=True, null=True)
    mac_id = models.TextField(blank=True, null=True)
    class Meta:
        ordering = ['-date','-timestamp']
        db_table = 'QLog_Meat'

    def __str__(self):
        return f"{self.id}_{self.device}"

class gps_qlog(models.Model):
    uuid = models.UUIDField(primary_key = True, default = uuid.uuid4,editable = False)
    warehouse_id = models.TextField(blank=True, null=True)
    timestamp = models.TextField(blank=True, null=True, verbose_name='time')
    date = models.TextField(blank=True, null=True)
    device_id = models.TextField(blank=True, null=True)
    sst_temp = models.FloatField(blank=True, null=True)
    temperature = models.FloatField(blank=True, null=True)
    tmp_temp = models.FloatField(blank=True, null=True)
    humidity = models.FloatField(blank=True, null=True)
    latitude = models.FloatField(blank=True, null=True)
    longitude= models.FloatField(blank=True, null=True)
    altitude = models.FloatField(blank=True, null=True)
    co2 = models.FloatField(blank=True, null=True)
    mac_id = models.TextField(blank=True, null=True)
    class Meta:
        ordering = ['-date','-timestamp']
        db_table = 'gps_qlog'

    def __str__(self):
        return f"{self.id}_{self.device}"