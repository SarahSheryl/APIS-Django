from rest_framework import serializers
from .models import QLogData,Meat,gps_qlog


class QLogDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = QLogData
        fields = (
            'warehouse_id',
                    'timestamp',
                    'date',
                    'device',
                   'tmp_temp',
                   'bme_rel_humidity',
                   'scd41_co2'
                )


class QLogMeatDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = Meat
        fields = (
                    'warehouse_id',
                    'timestamp',
                    'date',
                    'device',
                    'temperature',
                    'humidity',
                    'voc',
                    'carbondioxide',
                    'hydrogensulphide',
                    'ammonia',
                    'oxygen'

                )

class QLogGPSDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = gps_qlog
        fields = (
                    'warehouse_id',
                    'timestamp',
                    'date',
                    'device_id',
                    'temperature',
                    'humidity',
                    'latitude',
                    'longitude',
                    'altitude',
                    'co2'

                )
