from api.apps.core.renderers import ApiJSONRenderer

class QLogDataJSONRenderer(ApiJSONRenderer):
    object_label = 'data'
    pagination_object_label = 'data'
    pagination_count_label = 'data_count'

class QLogDataHeadersJSONRenderer(ApiJSONRenderer):
    object_label = 'headers'
    pagination_object_label = 'headers'
    pagination_count_label = 'headers_count'
