from django.contrib import admin
from .models import WarehouseData

admin.site.register(WarehouseData)
