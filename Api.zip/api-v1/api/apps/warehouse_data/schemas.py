from rest_framework.schemas import AutoSchema

import coreapi
import coreschema
import json


class WarehouseDataSchema(AutoSchema):

    def get_manual_fields(self, path, method):
        custom_fields = []

        if method.upper() == 'GET':

            custom_fields = [
                coreapi.Field(
                    "warehouse_id",
                    required=False,
                    location="query",
                    schema=coreschema.String(
                        description="Filter by warehouse id")
                ),
                coreapi.Field(
                    "device_id",
                    required=False,
                    location="query",
                    schema=coreschema.String(description="Filter by device id")
                ),
                coreapi.Field(
                    "device_type",
                    required=False,
                    location="query",
                    schema=coreschema.String(description="Filter by device type")
                ),
                coreapi.Field(
                    "fruit",
                    required=False,
                    location="query",
                    schema=coreschema.String(description="Filter by fruit")
                ),
                coreapi.Field(
                    "variety",
                    required=False,
                    location="query",
                    schema=coreschema.String(description="Filter by variety")
                ),
                coreapi.Field(
                    "start",
                    required=False,
                    location="query",
                    schema=coreschema.String(
                        description="Filter from start date. YYYY-MM-DD")
                ),
                coreapi.Field(
                    "end",
                    required=False,
                    location="query",
                    schema=coreschema.String(
                        description="Filter till end date. YYYY-MM-DD")
                ),
            ]

        return self._manual_fields + custom_fields
