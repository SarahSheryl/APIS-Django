from io import BytesIO 

from django.http import HttpResponse
from .secret import access_key,secret_access_key
import pandas as pd
import numpy as np
from api.apps.warehouses.models import Warehouses
import boto3
import os


def read_s3_contents(request):
  
    s3 = boto3.resource('s3',aws_access_key_id=access_key,aws_secret_access_key=secret_access_key )
    obj = s3.Object(bucket_name='qzense-report', key=f"UD001/2021/12/week-2021-12-01TO2021-12-06.pdf")
    response = obj.get()
    data = response['Body'].read()
    # download = s3.Bucket('qzense-report').download_file('monthly.pdf', 'monthly.pdf')
    return HttpResponse(data, content_type='application/pdf')

def upload_pdf_S3(pdf,start,end,warehouse,type):
   s3 = boto3.resource('s3',aws_access_key_id=access_key,aws_secret_access_key=secret_access_key)
  #  create_folder_for_user(pdf,start)

   my_bucket = s3.Bucket('qzense-report')
   folders = []
   for my_bucket_object in my_bucket.objects.all():
      if my_bucket_object.key.endswith('/'):
        folders.append(my_bucket_object.key[:-1])
   try:
     print('in try')

     file = s3.Bucket('qzense-report').put_object(
       Key=f"{warehouse}/{start[:4]}/{start[5:7]}/{type}-{start}TO{end}.pdf",
       Body=pdf)

    
     return print('true')
   except Exception as e:
     return print('False',e)

def getReportFromS3():
   s3 = boto3.resource('s3',aws_access_key_id=access_key,aws_secret_access_key=secret_access_key )
   my_bucket = s3.Bucket('qzense-report')
   folders = []
   for my_bucket_object in my_bucket.objects.all():
     print(my_bucket_object)
   

