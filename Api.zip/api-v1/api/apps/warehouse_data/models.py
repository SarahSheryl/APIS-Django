from django.db import models
from django.db.models import JSONField
import uuid

class WarehouseData(models.Model):
    # id = models.BigIntegerField(primary_key=True)
    uuid = models.UUIDField(primary_key = True, default = uuid.uuid4,editable = False)
    warehouse_id = models.TextField(blank=True, null=True)
    device_info = models.TextField(blank=True, null=True)

    # Metadata
    timestamp = models.TextField(blank=True, null=True, verbose_name='time')
    date = models.TextField(blank=True, null=True)
    fruit = models.TextField(blank=True, null=True)
    variety = models.TextField(blank=True, null=True)
    device = models.ForeignKey("devices.Devices", blank=True, null=True, on_delete=models.DO_NOTHING, to_field="device_id")
    position = models.TextField(blank=True, null=True)
    set = models.BigIntegerField(blank=True, null=True)

    # Device readings
    wavelength_610nm = models.FloatField(db_column='wv_610nm', blank=True,
                                         null=True)
    wavelength_680nm = models.FloatField(db_column='wv_680nm', blank=True,
                                         null=True)
    wavelength_730nm = models.FloatField(db_column='wv_730nm', blank=True,
                                         null=True)
    wavelength_760nm = models.FloatField(db_column='wv_760nm', blank=True,
                                         null=True)
    wavelength_810nm = models.FloatField(db_column='wv_810nm', blank=True,
                                         null=True)
    wavelength_860nm = models.FloatField(db_column='wv_860nm', blank=True,
                                         null=True)
    temp = models.FloatField(blank=True, null=True)



    # Predictions
    brix = models.FloatField(blank=True, null=True)
    felix = models.FloatField(blank=True, null=True)
    atago = models.FloatField(blank=True, null=True)
    dm = models.FloatField(blank=True, null=True)
    oldstatus = models.FloatField(blank=True, null=True)
    status = models.TextField(blank=True, null=True)
    action = models.TextField(blank=True,null=True)
    selflife = models.TextField(blank=True,null=True)

    # Misc
    batch_number = models.TextField(blank=True, null=True, verbose_name='batch')
    vendor_code = models.ForeignKey("vendor.Vendor",blank=True, null=True,on_delete=models.DO_NOTHING,verbose_name='vendor_code')

    #sensor_data = JSONField(blank=True, null=True)
    pressure = models.FloatField(blank=True, null=True)
    #CO2 = models.FloatField(blank=True, null=True)
    #CH4 = models.FloatField(blank=True, null=True)
    refractometer_brix = models.FloatField(blank=True, null=True)
    mac_id = models.TextField(blank=True, null=True)
    commodity = models.TextField(blank=True, null=True)
    commodity_variety = models.TextField(blank=True, null=True)
    spoilageindex = models.FloatField(blank=True, null=True)
    class Meta:
        # managed = False
        ordering = ['-date', '-timestamp']
        db_table = 'warehouse_data'

    def __str__(self):
        return f"{self.uuid}_{self.device}_{self.fruit}_{self.brix}"

class QscanMeat(models.Model):
    id = models.AutoField(primary_key=True)
    timestamp = models.TextField(blank=True, null=True, verbose_name='time',db_index=True)
    date = models.TextField(blank=True, null=True,db_index=True)
    warehouse_id = models.TextField(blank=True, null=True,db_index=True)
    device = models.TextField(blank=True, null=True,db_index=True)
    temperature = models.FloatField(blank=True,null=True)
    humidity = models.FloatField(blank=True,null=True)
    carbon_dioxide = models.FloatField(blank=True,null=True)
    oxygen = models.FloatField(blank=True,null=True)
    hydrogen_sulfide = models.FloatField(blank=True,null=True)
    ammonia = models.FloatField(blank=True,null=True)
    voc= models.FloatField(blank=True, null=True)
    goodbad = models.FloatField(blank=True, null=True) 
    mac_id = models.TextField(blank=True,null=True)
    meat = models.TextField(blank=True,null=True,default='Fish')
    species = models.TextField(blank=True,null=True,default='Mackerel')
    vendor_code = models.ForeignKey("vendor.Vendor",blank=True, null=True,on_delete=models.DO_NOTHING,verbose_name='vendor_code')
    batch_number = models.TextField(blank=True,null=True)

    class Meta:
        ordering = ['-date','-timestamp']

    def __str__(self):
        return f"{self.id}"


