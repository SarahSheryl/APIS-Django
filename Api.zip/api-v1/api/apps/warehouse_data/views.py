from rest_framework import generics, mixins, status, viewsets
from rest_framework.exceptions import NotFound
from rest_framework.permissions import (
    AllowAny, IsAuthenticated
)
from rest_framework.response import Response
from django.db.models.functions import Concat
from .models import WarehouseData,QscanMeat
from api.apps.warehouses.models import Warehouses
from api.apps.devices.models import Devices
from .renderers import WarehouseDataJSONRenderer, WarehouseDataHeadersJSONRenderer
from .serializers import WarehouseDataSerializer,GenerateDataSerializer,MeatDataSerializer
from .schemas import WarehouseDataSchema
from datetime import date
from django.shortcuts import render
from django.http import HttpResponse
from django.template.loader import render_to_string
import tempfile
from django.http import HttpResponse
from django.views.generic import View
from django.http import FileResponse
from django.template.loader import get_template
from .graph import PieChart,StackedBarChart,lineChart
from .secret import access_key,secret_access_key
import boto3
import botocore
import os
import pandas as pd
import numpy as np
from quickchart import QuickChart
from datetime import datetime
from django.template.loader import render_to_string
from django.core.files.storage import FileSystemStorage
from .utils import upload_pdf_S3,getReportFromS3
import ssl
import json
from weasyprint import HTML,default_url_fetcher
ssl._create_default_https_context = ssl._create_unverified_context

class WarehouseDataViewSet(mixins.ListModelMixin,
                           viewsets.GenericViewSet):
    """
    list:
    Return a list of all the warehouse data with given offset and limit.

    """
    schema = WarehouseDataSchema()
    queryset = WarehouseData.objects.select_related('device', 'device__device_type')
    permission_classes = (AllowAny,)
    renderer_classes = (WarehouseDataJSONRenderer,)
    serializer_class = WarehouseDataSerializer

    def get_queryset(self):
        queryset = self.queryset
        if not self.request.user.is_superuser:
            try:
                warehouse = Warehouses.objects.get(user=self.request.user)
             
            except Warehouses.DoesNotExist:
                return WarehouseData.objects.none()
            queryset = queryset.filter(warehouse_id=warehouse.warehouse_id)
        else:
            warehouse_id = self.request.query_params.get('warehouse_id', None)
            if warehouse_id is not None:
                queryset = queryset.filter(warehouse_id=warehouse_id)

        device = self.request.query_params.get('device', None)
        if device is not None:
            queryset = queryset.filter(device=device)

        device_type = self.request.query_params.get('device_type', None)
        if device_type is not None:
            queryset = queryset.filter(device__device_type__device_type=device_type)

        fruit = self.request.query_params.get('fruit', None)
        if fruit is not None:
            queryset = queryset.filter(fruit=fruit)

        variety = self.request.query_params.get('variety', None)
        if variety is not None:
            queryset = queryset.filter(variety=variety)

        commodity = self.request.query_params.get('commodity', None)
        if commodity is not None:
            queryset = queryset.filter(commodity=commodity)

        commodity_variety = self.request.query_params.get('commodity_variety', None)
        if commodity_variety is not None:
            queryset = queryset.filter(commodity_variety=commodity_variety)


        start = self.request.query_params.get('start', None)
        end = self.request.query_params.get('end', None)
        if start is not None and end is not None:
            queryset = queryset.annotate(timedate=Concat('date','timestamp'))
            """ creates a virtual column timedate with time and date in it -- date and time filter"""
            queryset = queryset.filter(timedate__range=(start, end))
            """print(queryset);"""
        return queryset

    def list(self, request):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.serializer_class(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


class WarehouseDataHeadersRetrieveAPIView(generics.RetrieveAPIView):
    """
    get:
    Return a list of all headers of table.

    """
    permission_classes = (AllowAny,)
    renderer_classes = (WarehouseDataHeadersJSONRenderer,)
    pagination_class = None

    def retrieve(self, request):
        labels = {}

        for field in WarehouseDataSerializer.Meta.model._meta.get_fields():
            if field.name in WarehouseDataSerializer.Meta.fields:
                labels[field.name] = field.verbose_name

        for field in WarehouseDataSerializer.Meta.fields:
            if labels.get(field, None) is None:
                labels[field] = field

        return Response({'results': labels})

class GenerateReport(mixins.ListModelMixin,
                           viewsets.GenericViewSet):
    """
    list:
    Return a list of all the warehouse data with given offset and limit.

    """
    #schema = WarehouseDataSchema()
    # queryset = WarehouseData.objects.all()
    queryset = WarehouseData.objects.filter(date=date.today())
    #date= date.today()
    permission_classes = (AllowAny,)
    pagination_class = None
    #renderer_classes = (WarehouseDataJSONRenderer,)
    serializer_class = GenerateDataSerializer

    def get_queryset(self):
        queryset = self.queryset
        if not self.request.user.is_superuser:
            try:
                warehouse = Warehouses.objects.get(user=self.request.user)
            except Warehouses.DoesNotExist:
                return WarehouseData.objects.none()
            queryset = queryset.filter(warehouse_id=warehouse.warehouse_id)
        else:
            warehouse_id = self.request.query_params.get('warehouse_id', None)
            if warehouse_id is not None:
                queryset = queryset.filter(warehouse_id=warehouse_id)
        return queryset



def Citrus(df):
    # queryset = WarehouseData.objects.values_list('warehouse_id','date','fruit','variety','brix').filter(date__range = ['2021-11-01','2021-11-02'],fruit='CITRUS')
    # df = pd.DataFrame(list(queryset))
    # headers = ['warehouse_id','date','fruit','variety','brix']   
    # df.columns = headers
    df = df[df['fruit'] == 'CITRUS']
    Varieties = df['variety'].unique()
    df.brix = df.brix.round(1)
    # print('variety',Varieties)

    def Variety(v,df):
        # df = pd.DataFrame(list(queryset))
        # headers = ['warehouse_id','date','fruit','variety','brix']   
        # df.columns = headers
        # df = self.df

        # df.brix = df.brix.round(1)
        df = df[(df.variety == v )]
        totallabel=df.shape[0]
        print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<')
        print(totallabel)
        
        sf = df['brix'].value_counts().sort_index(ascending=True)
        df = pd.DataFrame({'brix':sf.index, 'freq':sf.values}).copy()
        # print(df)
        # print('typeeeeeeeeeeeeeee',type(df))
        label = list(df.brix)
        total = list(df.freq)
        if(v == 'KINNOW'):
            df['freq'] = np.where(df.brix < 9,np.nan,df['freq'])
            
        else:
             df['freq'] = np.where(df.brix < 8,np.nan,df['freq'])

        acceptedbrix = list(df.freq) 
        acceptedbrixlabel = df['freq'].dropna().astype(int).sum()
        acceptedbrixpercent = (((acceptedbrixlabel/totallabel)*100).round(1))
        Graph = lineChart(v,label, total, acceptedbrix,totallabel,acceptedbrixlabel,acceptedbrixpercent)
        return Graph
    urls = []
    for v in Varieties:
        x = Variety(v,df)
        print("varieties urlssssss",x)
        url = urls.append(x)
       
        print(url)
        
    # print(url)
        
    
    # print('x outside',x)

    return urls


def Mangoes(df):
    # queryset = WarehouseData.objects.values_list('warehouse_id','date','fruit','variety','brix').filter(date__range = ['2021-11-01','2021-11-02'],fruit='CITRUS')
    # df = pd.DataFrame(list(queryset))
    # headers = ['warehouse_id','date','fruit','variety','brix']   
    # df.columns = headers
    df = df[df['fruit'] == 'MANGO']
    Varieties = df['variety'].unique()
    print('VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV',Varieties)
    df.brix = df.brix.round(1)
    # print('variety',Varieties)

    def Variety(v,df):
        # df = pd.DataFrame(list(queryset))
        # headers = ['warehouse_id','date','fruit','variety','brix']   
        # df.columns = headers
        # df = self.df

        # df.brix = df.brix.round(1)
        df = df[(df.variety == v )]
        totallabel=df.shape[0]
        print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<')
        print(totallabel)
        
        sf = df['brix'].value_counts().sort_index(ascending=True)
        df = pd.DataFrame({'brix':sf.index, 'freq':sf.values}).copy()
        # print(df)
        # print('typeeeeeeeeeeeeeee',type(df))
        label = list(df.brix)
        total = list(df.freq)
        if(v == 'SINDHURA'):
            df['freq'] = np.where((df.brix < 12)|(df.brix > 22),np.nan,df['freq'])
            # print('MMMMMMMMMMMMMMMMMMMMMMMMMMM', df['freq'])  
            acceptedbrix = list(df.freq)  
            # print('MMMMMMMMMMMMMMMMMMMMMMMMMMM',acceptedbrix)             
            acceptedbrixlabel = df['freq'].dropna().astype(int).sum()
            # print('<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>',v)
            # print(acceptedbrixlabel)
            acceptedbrixpercent = ((acceptedbrixlabel/totallabel)*100).round(1)

        elif( v == 'BENISHAN'):
             df['freq'] = np.where((df.brix < 14)|(df.brix > 21),np.nan,df['freq'])
             acceptedbrix = list(df.freq)   
            #  print('MMMMMMMMMMMMMMMMMMMMMMMMMMM',acceptedbrix)            
             acceptedbrixlabel = df['freq'].dropna().astype(int).sum()
            # print('<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>',v)
            # print(acceptedbrixlabel)
             acceptedbrixpercent = ((acceptedbrixlabel/totallabel)*100).round(1)

        else:
             df['freq'] = np.where((df.brix < 14)|(df.brix > 22),np.nan,df['freq'])
             acceptedbrix = list(df.freq)  
            #  print('MMMMMMMMMMMMMMMMMMMMMMMMMMMMMM',acceptedbrix)           
             acceptedbrixlabel = df['freq'].dropna().astype(int).sum()
            # print('<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>',v)
            # print(acceptedbrixlabel)
             acceptedbrixpercent = ((acceptedbrixlabel/totallabel)*100).round(1)

        # acceptedbrix = list(df.freq) 
        # acceptedbrixlabel = df['freq'].dropna().astype(int).sum()
        # acceptedbrixpercent = (((acceptedbrixlabel/totallabel)*100).round(1))
        Graph = lineChart(v,label, total, acceptedbrix,totallabel,acceptedbrixlabel,acceptedbrixpercent)
        return Graph
    urls = []
    for v in Varieties:
        x = Variety(v,df)
        print("varieties urlssssss",x)
        url = urls.append(x)
       
        print('Mannnnngoooooo',url)
        
    # print(url)
        
    
    # print('x outside',x)

    return urls

def Apple(df):
    df = df[df['fruit'] == 'APPLE']
    # queryset = WarehouseData.objects.values_list('warehouse_id','date','fruit','variety','brix','device_id','action','status').filter(date__range = ['2021-11-01','2021-11-02'],fruit ='APPLE')
    # df = pd.DataFrame(list(queryset))
    # headers = ['warehouse_id','date','fruit','variety','brix','device_id','action','status']
    # df.columns = headers
    Varieties = df['variety'].unique()
    # print('Apple Variety',Varieties)
    pieurls = []

    def applePie(v,df):
        # queryset = WarehouseData.objects.values_list('warehouse_id','date','fruit','variety','brix','device_id','action','status').filter(date__range = ['2021-11-01','2021-11-02'],fruit ='APPLE')
        # df = pd.DataFrame(list(queryset))
        # headers = ['warehouse_id','date','fruit','variety','brix','device_id','action','status']
        # df.columns = headers
        df = df[(df.variety == v )]
        print('**************df',df)
        accepted = df[(df.status == 'GOOD(AC)') | (df.status == 'BEST(AC)') ].shape[0]
        average = df[(df.status == 'AVERAGE(RJ)')].shape[0]
        bad = df[(df.status == 'BAD(RJ)')].shape[0]
        apple = [accepted,bad,average]
        print(v)
        print(">>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<")
        print(accepted,bad,average)
        print(">>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<")
        labels=['Accepted','Bad','Average']
        backgroundcolor = ["rgba(149, 198, 35, 1)", "rgba(207, 52, 118, 1)","rgba(207, 113, 175, 1)"]
        url  = PieChart(apple,labels,v,backgroundcolor)
        print(url)
        return url

    def appleBrix(v,df):
        # queryset = WarehouseData.objects.values_list('warehouse_id','date','fruit','variety','brix').filter(date__range = ['2021-11-01','2021-11-02'],fruit='APPLE')
        # df = pd.DataFrame(list(queryset))
        # headers = ['warehouse_id','date','fruit','variety','brix']   
        # df.columns = headers
        df.brix = df.brix.round(1)
        df = df[(df.variety == v )]
        totallabel=df.shape[0]
        
        # print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<')
        # print(totallabel)
        # print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
        # print(totallabel)
        # print(df[(df.variety == 'SHIML' )])
        sf = df['brix'].value_counts().sort_index(ascending=True)
        df = pd.DataFrame({'brix':sf.index, 'freq':sf.values}).copy()
        # print(df)
        # print('typeeeeeeeeeeeeeee',type(df))
        label = list(df.brix)
        total = list(df.freq)
        # print('totall>>>>>>>>>>>>>>>>>>>shimla',label,total)
        if (v == 'RED DELICIOUS' ):
            # df['freq'] = np.where( (df.brix < 11)|(df.brix > 13.0),'null',df['freq'])
            df['freq'] = np.where( (df.brix < 11)|(df.brix > 13.0),np.nan,df['freq'])
            acceptedbrix = list(df.freq)             
            acceptedbrixlabel = df['freq'].dropna().astype(int).sum()
            # print('<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>',v)
            # print(acceptedbrixlabel)
            acceptedbrixpercent = ((acceptedbrixlabel/totallabel)*100).round(1)
            
        elif (v == 'SHIMLA'):
            df['freq'] = np.where( (df.brix < 11)|(df.brix > 13.0),np.nan,df['freq'])
            # df['freq'] = np.where( (df.brix < 11)|(df.brix > 13.0),'null',df['freq'])
            acceptedbrix = list(df.freq) 
            acceptedbrixlabel = df['freq'].dropna().astype(int).sum()
            acceptedbrixpercent = (((acceptedbrixlabel/totallabel)*100).round(1))
            # print('<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>',v)
            # print(acceptedbrixlabel)
            
            # acceptedbrixlabel = df['freq'].dropna().astype(int).sum()
            # print("!!!!!!!!!!!!!!!!!!!!!SHIMLA>>>>>>>>>>>>>>",v,acceptedbrix)
        elif (v =='GALA'):
            # df['freq'] = np.where((df.brix < 11) | (df.brix > 14.0) ,'null',df['freq'])
            df['freq'] = np.where((df.brix < 11) | (df.brix > 14.0) ,np.nan,df['freq'])
            acceptedbrix = list(df.freq) 
            acceptedbrixlabel = df['freq'].dropna().astype(int).sum()
            # print('<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>',v)
            # print(acceptedbrixlabel)
            acceptedbrixpercent = ((acceptedbrixlabel/totallabel)*100).round(1)
            # print("!!!!!!!!!!!!!!!!!!!!!",v,acceptedbrix)
            # df['freq'] = np.where((df.brix < 11) | (df.brix > 14.0) ,np.nan,df['freq'])
            # acceptedbrixlabel = df['freq'].dropna().astype(int).sum()
        elif (v =='FUJI'):
            df['freq'] = np.where((df.brix < 14) | (df.brix > 17) ,np.nan,df['freq'])
            acceptedbrix = list(df.freq) 
            acceptedbrixlabel = df['freq'].dropna().astype(int).sum()
            # print('<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>',v)
            # print(acceptedbrixlabel)
            acceptedbrixpercent = ((acceptedbrixlabel/totallabel)*100).round(1)
            # print("!!!!!!!!!!!!!!!!!!!!!",v,acceptedbrix)
            # df['freq'] = np.where((df.brix < 14) | (df.brix > 17) ,np.nan,df['freq'])
            # acceptedbrixlabel = df['freq'].dropna().astype(int).sum()
        elif (v =='GRANNYSMITH'):
            df['freq'] = np.where((df.brix < 10) | (df.brix > 13) ,np.nan,df['freq'])
            acceptedbrix = list(df.freq) 
            acceptedbrixlabel = df['freq'].dropna().astype(int).sum()
            # print('<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>',v)
            # print(acceptedbrixlabel)
            acceptedbrixpercent = ((acceptedbrixlabel/totallabel)*100).round(1)
            # print("!!!!!!!!!!!!!!!!!!!!!",v,acceptedbrix)
            # df['freq'] = np.where((df.brix < 10) | (df.brix > 13) ,np.nan,df['freq'])
            # acceptedbrixlabel = df['freq'].dropna().astype(int).sum()
        else:
            df['freq'] = np.where((df.brix < 11) | (df.brix > 15) ,np.nan,df['freq'])
            acceptedbrix = list(df.freq) 
            acceptedbrixlabel = df['freq'].dropna().astype(int).sum()
            # print('<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>',v)
            # print(acceptedbrixlabel)
            acceptedbrixpercent = ((acceptedbrixlabel/totallabel)*100).round(1)
            # print("!!!!!!!!!!!!!!!!!!!!!",v,acceptedbrix)
            # df['freq'] = np.where((df.brix < 11) | (df.brix > 15) ,np.nan,df['freq'])
            # acceptedbrixlabel = df['freq'].dropna().astype(int).sum()

        
        # print('acceptedbrix',acceptedbrix)
        # print('total',total)
        # print('label',label)
        # label = [1,2,3,4,5,6]
        # total = [1,2,3,4,5,6]
        # acceptedbrix= [1,2,3,4,5,6]
        print(v,label, total, acceptedbrix,totallabel,acceptedbrixlabel)
        Graph = lineChart(v,label, total, acceptedbrix,totallabel,acceptedbrixlabel,acceptedbrixpercent)
        
        return Graph

    pieurls = []
    lineurls = []
    for v in Varieties:
        x = applePie(v,df)
        # y = appleBrix(v)
        # print("varieties urlss ssss",x)
        piegraphs = pieurls.append(x)
        # linegraph = lineurls.append(y)

    for v in Varieties:
        x = appleBrix(v,df)
        # print("*************varieties lineurlss ssss",x)
        lineurls.append(x)

    # print('******************Applee urls',[lineurls,pieurls])
       
    
        
    # print('Applleeeeeeeeeeeeeeeeeeeee',graphs)

    return [pieurls,lineurls]

    

def Banana(df):
    df = df[df['fruit'] == 'BANANA']
    Varieties = df['variety'].unique()
    bananaurl = []

    def bananaPie(v,df):
        df = df[(df.variety == v )]
        underripe = df[(df.status == 'STAGE : 1')].shape[0]
        accepted = df[(df.status == 'STAGE : 3')  | (df.status == 'STAGE : 2')].shape[0]
        overripe = df[(df.status == 'STAGE : 4')| (df.status == 'STAGE : 5')].shape[0]
        banana = [accepted,underripe,overripe]
        labels = ['Accepted','Under Ripe','Over Ripe']
        backgroundcolor = ["rgba(149, 198, 35, 1)", "rgba(207, 52, 118, 1)","rgba(207, 113, 175, 1)"]
        url = PieChart(banana,labels,v,backgroundcolor)
        return url 

    for v in Varieties:
        x = bananaPie(v,df)
        bananaurl.append(x)

    
    # print(underripe)
    # print('**********************************')
    # print(accepted)
    # print('**********************************')
    # print(overripe)
    return bananaurl

def Sapota(df):
    # queryset = WarehouseData.objects.values_list('warehouse_id','date','fruit','variety','brix','device_id','action','status').filter(date__range = ['2021-10-01','2021-10-02'],fruit ='BANANA')
    
    # df = pd.DataFrame(list(queryset))
    # headers = ['warehouse_id','date','fruit','variety','brix','device_id','action','status']
    # df.columns = headers
    if 'SAPOTA' in df.values:
        df = df[df['fruit'] == 'SAPOTA']
        print('Sapotaaaaaaaaaaaaa!!!!!!!!!!!!!!!!!!!!!!')
        print('Sapotaaaaaaaaaaaaa!!!!!!!!!!!!!!!!!!!!!!',df)
        stage1 = df[(df.status == 'STAGE : 1')].shape[0]
        stage2 = df[(df.status == 'STAGE : 2')].shape[0]
        stage3 = df[(df.status == 'STAGE : 3')].shape[0]
        sapota = [stage1,stage2,stage3]
        labels = ['Stage 1','Stage 2','Stage 3']
        backgroundcolor = ["rgba(207, 113, 175, 1)","rgb(118, 142,60,1)","rgba(149, 198, 35, 1)"]
        url = PieChart(sapota,labels,'SAPOTA',backgroundcolor)
        return url
    else:
        return []
# "rgba(149, 198, 35, 1)", "rgba(207, 52, 118, 1)","rgba(207, 113, 175, 1)"
#rgb(131, 173, 31),

def Papaya(df):
    # queryset = WarehouseData.objects.values_list('warehouse_id','date','fruit','variety','brix','device_id','action','status').filter(date__range = ['2021-10-01','2021-10-02'],fruit ='BANANA')
    
    # df = pd.DataFrame(list(queryset))
    # headers = ['warehouse_id','date','fruit','variety','brix','device_id','action','status']
    # df.columns = headers
    if 'PAPAYA' in df.values:
        df = df[df['fruit'] == 'PAPAYA']
        stage1 = df[(df.status == 'STAGE : 1')].shape[0]
        stage2 = df[(df.status == 'STAGE : 2')].shape[0]
        stage3 = df[(df.status == 'STAGE : 3')].shape[0]
        stage4 = df[(df.status == 'STAGE : 4')].shape[0]
        stage5 = df[(df.status == 'STAGE : 5')].shape[0]
        stage6 = df[(df.status == 'STAGE : 6')].shape[0]
        papaya = [stage1,stage2,stage3,stage4,stage5,stage6]
        labels = ['Stage 1','Stage 2','Stage 3','Stages 4','Stage 5','Stage 6']
        backgroundcolor = ["rgb(149,198,35,1)","rgb(118,142,60,1)","rgba(126,180,0, 1)","rgba(207,52,118, 1)","rgb(207,113,175,1)","rgb(150,74,106,1)"]
        url = PieChart(papaya,labels,'PAPAYA',backgroundcolor)
        print('PAPAYA',url)
        return url
    else:
        return []

def preprocess(df,types,types2='null'):
        df.reset_index(inplace = True,drop = True)
        print("OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO",df['warehouse_id'].unique(),len(df))
        variety = list(filter(None,df['variety'].unique()))
        fruit = list(filter(None,df['fruit'].unique()))
        # print('VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV',variety,fruit,df.iloc[972])
        try:
            for i in range(len(df)):
                if df['fruit'][i] == 'CITRUS':
                    if pd.to_numeric(df['brix'][i])<8:
                        df['action'][i] = 'REJECT'
                    else:
                        df['action'][i] = 'ACCEPT'
            
            for i in range(len(df)):
                if df['variety'][i] == 'RED DELICIOUS':
                    if pd.to_numeric(df['brix'][i])<11 or pd.to_numeric(df['brix'][i])>13:
                        df['action'][i] = 'REJECT'
            
            for i in range(len(df)):
                if df['variety'][i] == 'SHIMLA':
                    if pd.to_numeric(df['brix'][i])<11 or pd.to_numeric(df['brix'][i])>13:
                        df['action'][i] = 'REJECT'
            
            for i in range(len(df)):
                if df['variety'][i] == 'GALA':
                    if pd.to_numeric(df['brix'][i])<11 or pd.to_numeric(df['brix'][i])>14:
                        df['action'][i] = 'REJECT'
            

            for i in range(len(df)):
                if df['variety'][i] == 'FUJI':
                    if pd.to_numeric(df['brix'][i])<14 or pd.to_numeric(df['brix'][i])>17:
                        df['action'][i] = 'REJECT'
            
            for i in range(len(df)):
                if df['variety'][i] == 'GRANNYSMITH':
                    if pd.to_numeric(df['brix'][i])<10 or pd.to_numeric(df['brix'][i])>13:
                        df['action'][i] = 'REJECT'

            for i in range(len(df)):
                if df['variety'][i] == 'GENERAL':
                    if pd.to_numeric(df['brix'][i])<14 or pd.to_numeric(df['brix'][i])>17:
                        df['action'][i] = 'REJECT'

            # for i in range(len(df)):
            #     if df['variety'][i] == 'ALPHONSO':
            #         if pd.to_numeric(df['brix'][i])<14 or pd.to_numeric(df['brix'][i])>17:
            #             df['action'][i] = 'REJECT'

            for i in range(len(df)):
                if df['variety'][i] == 'SINDHURA':
                    if pd.to_numeric(df['brix'][i])<14 or pd.to_numeric(df['brix'][i])>17:
                        df['action'][i] = 'REJECT'

            for i in range(len(df)):
                if df['variety'][i] == 'BENISHAN':
                    if pd.to_numeric(df['brix'][i])< 14 or pd.to_numeric(df['brix'][i])>21:
                        df['action'][i] = 'REJECT'

      
            df['action'] = df['action'].str.upper()
            
            if types2 == 'null':
                Data_fruit = df[['action',types]].copy()


                Data_fruit.reset_index(inplace = True)
    # Data_fruit = Data_fruit.dropna()
                Data_fruit['ACCEPT'] = Data_fruit['action'] == 'ACCEPT'
                Data_fruit['REJECT'] =  Data_fruit['action'] == 'REJECT'
    # Data_fruit = Data_fruit.groupby('Vendor_code').aggregate(np.sum)
#     display(Data_fruit)

                Data_fruit = Data_fruit.groupby(types).aggregate(np.sum)
#     displa    y(Data_fruit)
                # print("*****************Data_fruit***************************",Data_fruit)
                # print('')
                Data_fruit['ACCEPT%'] = (100*Data_fruit['ACCEPT']/(Data_fruit['ACCEPT']+Data_fruit['REJECT'])).round(1)
                Data_fruit['REJECT%'] = (100*Data_fruit['REJECT']/(Data_fruit['ACCEPT']+Data_fruit['REJECT'])).round(1)
                Data_fruit['Star_rating'] = Data_fruit['ACCEPT%']/20
                Data_fruit = Data_fruit.sort_values('Star_rating',ascending=False)
                a = get_list(Data_fruit)
                
                return a[0],a[1],a[2], list(zip(Data_fruit.index,Data_fruit['ACCEPT']+Data_fruit['REJECT'],Data_fruit['ACCEPT%']))
            else:
                Data_variety = df[['action',types,types2]].copy()
                # print("???????????????????????????df?????")
                # print("???????????????????????????df?????",Data_variety)
                Data_variety.reset_index(inplace = True)
                Data_variety = Data_variety.dropna()
                Data_variety['No. ACCEPTED'] = Data_variety['action'] == 'ACCEPT'
                Data_variety['No. REJECTED'] =  Data_variety['action'] == 'REJECT'
                # Data = Data.groupby('Vendor_code').aggregate(np.sum)
                # print(Data_variety)
                Data_variety = Data_variety.groupby([types,types2]).aggregate(np.sum)
                # Data_variety = Data_variety.groupby(['Variety']).aggregate(np.sum)
                # Data_variety.reset_index(inplace = True)

                # print(Data_variety)
                # Data_variety['ACCEPT%'] = 100*Data_variety['ACCEPT']/(Data_variety['ACCEPT']+Data['REJECT'])
                # Data_variety['REJECT%'] = 100*Data_variety['REJECT']/(Data_variety['ACCEPT']+Data['REJECT'])
                # Data_variety['Star_rating'] = Data_variety['ACCEPT%']/20
                Data_variety['ACCEPT%'] = (100*Data_variety['No. ACCEPTED'].values/(Data_variety['No. ACCEPTED'].values+Data_variety['No. REJECTED'].values)).round(1)
                Data_variety['REJECT%'] = (100*Data_variety['No. REJECTED'].values/(Data_variety['No. ACCEPTED'].values+Data_variety['No. REJECTED'].values)).round(1)
                Data_variety['Star_rating'] = Data_variety['ACCEPT%'].values/20
                # Data_variety
                # print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>data variety')
                # # Data_variety.to_csv('datavariety.csv')

                # print(Data_variety)
                
                Data_v = Data_variety.reset_index()
                Data_v=Data_v.sort_values(by=['Star_rating'],ascending=False)
                # print('Data_v#####################################',Data_v)
                Data_v = Data_v.set_index(Data_v['variety'])
                Data_v['total'] = Data_v['No. ACCEPTED']+Data_v['No. REJECTED']
                Data_variety.drop(columns='index',inplace = True)
                Data_variety = Data_variety.reset_index().set_index('variety')
                Data_variety=Data_variety.sort_values(by=['Star_rating'],ascending=False)
                print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>data v')
                # print(Data_v)

                # print(get_listbyvariety(Data_variety))
                urls = []
                # Data_variety = Data_variety.reset_index().set_index([Data_variety['url'],Data_variety['variety']])
                # Data_variety['total'] = Data_variety['No. ACCEPTED']+Data_variety['No. ACCEPTED']
          
                for i in variety:
                    print('varrrrrrrrrrrrrrrrrrrrrrrr')
                    print('varrrrrrrrrrrrrrrrrrrrrrrr',variety)
                    abc = get_listbyvariety(Data_variety,i)
                    url =  StackedBarChart(abc[0],abc[1],abc[2],i)
                    print("??????????????????????????? lol ?????????????????",lol(Data_v,i))
                    a = lol(Data_v,i)
                    urls.append([url,a])
                print('urls!!!!!!!!!!!!!!!',urls)
        except Exception as e:
            print('EEEEEEEEEEEEEEEEEEEEEEEEEE', e)           
        return urls
                # ,list(zip(Data_variety.index,Data_variety['vendor_code'],Data_variety['No. ACCEPTED']+Data_variety['No. ACCEPTED']))
            # return get_list(Data_fruit)


def lol (Data_v,vname):
            print("??????????????????????????? lol ?????????????????",Data_v)
            return vname,list(zip((Data_v[Data_v['variety']==vname][['vendor_code','total','ACCEPT%']]).values))

        
        # print(variety)

        
def get_listbyvariety(Data_variety,variety):
            # Data_variety.to_csv('datavariety.csv')
            # print('?????????????????Varehiety',variety)
            # print('*******************type',type(Data_variety[['vendor_code', 'ACCEPT%', 'REJECT%']].reset_index().set_index('variety').loc[variety]))
            a = []
            # Data_variety.to_csv('sendamith.csv')
            for i in Data_variety.reset_index().set_index('variety').index.unique():
                try:
                    for j in Data_variety[['vendor_code', 'ACCEPT%', 'REJECT%']].reset_index().set_index('variety').loc[variety].columns:
                        a = a + [list(Data_variety[['vendor_code', 'ACCEPT%', 'REJECT%']].reset_index().set_index('variety').loc[variety][j])]
                except:
                    for j in pd.DataFrame(Data_variety[['vendor_code', 'ACCEPT%', 'REJECT%']].reset_index().set_index('variety').loc[variety]).T.columns:
                        a = a + [list(pd.DataFrame(Data_variety[['vendor_code', 'ACCEPT%', 'REJECT%']].reset_index().set_index('variety').loc[variety]).T[j])]


            for i in range(1,len(a)) :
                if i %3 ==0:
                    abc = list(a[i:i+3])
                    # print('abc??????????????',abc)
                    url =  StackedBarChart(abc[0],abc[1],abc[2],variety)
                    # print('url??????????????',url)
                    
                    return(list(a[i:i+3]))

        
       
def get_list(Data):
            return list(Data.index),list(Data['ACCEPT%'].round(2)),list(Data['REJECT%'].round(2))


class GeneratePdf(mixins.ListModelMixin,viewsets.GenericViewSet):
    queryset = WarehouseData.objects.values_list('warehouse_id','date','fruit','variety','brix','device_id','action','status','vendor_code__vendor_code')
    permission_classes = (AllowAny,)
    renderer_classes = (WarehouseDataJSONRenderer,)
    serializer_class = WarehouseDataSerializer
    start = 0
    end = 0
    
    def get_queryset(self, **kwargs):
       
         queryset = self.queryset
         self.type = self.request.query_params.get('type', None)
         queryset = self.queryset
         if self.type is None:
            if not self.request.user.is_superuser:
                try:
                    
                    warehouse = Warehouses.objects.get(user=self.request.user)
                    
                except Warehouses.DoesNotExist:
                    return WarehouseData.objects.none()
                queryset = queryset.filter(warehouse_id=warehouse.warehouse_id)
            else:
                warehouse_id = self.request.query_params.get('warehouse_id', None)
                if warehouse_id is not None:
                    queryset = queryset.filter(warehouse_id=warehouse_id)
            self.start = self.request.query_params.get('start', None)
            self.end = self.request.query_params.get('end', None)
            if self.start is not None and self.end is not None:
                 queryset = queryset.filter(date__range=(self.start,self.end))
                 print(queryset)
            return queryset
         else:
            self.start = self.request.query_params.get('start', None)
            self.end = self.request.query_params.get('end', None)
            if self.start is not None and self.end is not None:
                 queryset = queryset.filter(date__range=(self.start, self.end))
            # queryset = queryset.annotate(timedate=Concat('date','timestamp'))
            # print(start,end)
            return queryset
        # print('Sarah is right!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
           

    
    # print(start,end)

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        print(self.start,self.end)
        df = pd.DataFrame(list(queryset))
        headers = ['warehouse_id','date','fruit','variety','brix','device_id','action','status','vendor_code']
       
        df.columns = headers
        df = df[df['vendor_code'].notna()]
        print(df)
        fruits = df['fruit'].unique()
        list_variety = df['variety'].unique()
       
        w_list = df['warehouse_id'].unique()
        print(w_list)
        for w in w_list:
            print(w)
            dfd = df[df['warehouse_id'] == w].copy()
            print(dfd)
 
        
            def Graphs(argument):
                switcher = {
                    'CITRUS': Citrus(dfd),
                    'BANANA': Banana(dfd),
                    'APPLE':Apple(dfd),
                    'SAPOTA':Sapota(dfd),
                    'PAPAYA':Papaya(dfd),
                    'MANGO':Mangoes(dfd)
                    }
                return switcher.get(argument,'invalid')

            citrus = Graphs('CITRUS')
            sapota = Graphs('SAPOTA')
            payapa = Graphs('PAPAYA')
            banana = Graphs('BANANA')
            apple = Graphs('APPLE')
            mango = Graphs('MANGO')
            try:
                labelf,acceptf,rejectf,var=preprocess(dfd,'variety')
                labelv,acceptv,rejectv,vendor=preprocess(dfd,'vendor_code')
                varietybyvendor =preprocess(dfd,'variety','vendor_code')
                print('The results!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!',varietybyvendor)
            except Exception as e:
                print("errrrrror",e)
            stackedbarvariety = StackedBarChart(labelf,acceptf,rejectf,'Fruit Varieties')
            stackedbarvendor = StackedBarChart(labelv,acceptv,rejectv,'Vendor')
            context_dict={
                'banana':banana,
                'papaya':payapa,
                'sapota':sapota,
                'citrus':citrus,
                'apple':apple,
                'mango':mango,
                'stackedbarvariety':stackedbarvariety,
                'stackedbarvendor':stackedbarvendor,
                'variety':var,
                'vendor':vendor,
                'vendorbyvariety':varietybyvendor,
                'start':self.start,
                'end':self.end
           
            }

            html_string = render_to_string('chart.html', context_dict)
            html = HTML(string=html_string,base_url=request.build_absolute_uri())
         
            html.write_pdf(target='/tmp/mypdf.pdf')
            fs = FileSystemStorage('/tmp')
            with fs.open('mypdf.pdf') as pdf:
                if self.type is not None: 
                    upload = upload_pdf_S3(pdf,self.start,self.end,w,self.type)
                else:
                    response = HttpResponse(pdf, content_type='application/pdf')
                    response['Content-Disposition'] = 'filename="report.pdf"'
                    return response
        return HttpResponse('Completed')

class CustomizedPdf(mixins.ListModelMixin,viewsets.GenericViewSet):
    queryset = WarehouseData.objects.values_list('warehouse_id','date','fruit','variety','brix','device_id','action','status','vendor_code__vendor_code')
    permission_classes = (AllowAny,)
    renderer_classes = (WarehouseDataJSONRenderer,)
    serializer_class = WarehouseDataSerializer
    start = 0
    end = 0
    
    def get_queryset(self, **kwargs):
       
         queryset = self.queryset
         if not self.request.user.is_superuser:
             try:
                 warehouse = Warehouses.objects.get(user=self.request.user)
             except Warehouses.DoesNotExist:
                 return WarehouseData.objects.none()
             queryset = queryset.filter(warehouse_id=warehouse.warehouse_id)
         else:
             warehouse_id = self.request.query_params.get('warehouse_id', None)
             if warehouse_id is not None:
                 queryset = queryset.filter(warehouse_id=warehouse_id)
                 self.start = self.request.query_params.get('start', None)
                 self.end = self.request.query_params.get('end', None)
                 if self.start is not None and self.end is not None:
                    queryset = queryset.filter(date__range=(self.start,self.end))
                    queryset = queryset.filter(warehouse_id=warehouse.warehouse_id)
                    print(queryset)
                 return queryset

    def list(self, request, *args, **kwargs):
        
        queryset = self.get_queryset()
        print(self.start,self.end)
  
    
        df = pd.DataFrame(list(queryset))
        headers = ['warehouse_id','date','fruit','variety','brix','device_id','action','status','vendor_code']
       
        df.columns = headers
        df = df[df['vendor_code'].notna()]
        print(df)
        
        fruits = df['fruit'].unique()
 
        def Graphs(argument):
            switcher = {
                'CITRUS': Citrus(df),
                'BANANA': Banana(df),
                'APPLE':Apple(df),
                'SAPOTA':Sapota(df),
                'PAPAYA':Payapa(df),
                }
            return switcher.get(argument,'invalid')

        citrus = Graphs('CITRUS')
        papaya = Graphs('PAPAYA')
        banana = Graphs('BANANA')
        apple = Graphs('APPLE')
        sapota = Graphs('SAPOTA')

        try:
           
            labelf,acceptf,rejectf,var=preprocess(df,'variety')
            labelv,acceptv,rejectv,vendor=preprocess(df,'vendor_code')
            varietybyvendor =preprocess(df,'variety','vendor_code')
    
            print('The results!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!',varietybyvendor)
        except Exception as e:
            print("errrrrror",e)
        stackedbarvariety = StackedBarChart(labelf,acceptf,rejectf,'Fruit Varieties')
        stackedbarvendor = StackedBarChart(labelv,acceptv,rejectv,'Vendor')

        context_dict={
            'brix': [10,20,30,40,50],
            'banana':banana,
            'papaya':papaya,
            'sapota':sapota,
            'citrus':citrus,
            'apple':apple,
            'stackedbarvariety':stackedbarvariety,
            'stackedbarvendor':stackedbarvendor,
            'variety':var,
            'vendor':vendor,
            'vendorbyvariety':varietybyvendor,
            'start':self.start,
            'end':self.end
          
        }
        html_string = render_to_string('chart.html', context_dict)
        html = HTML(string=html_string,base_url=request.build_absolute_uri())
        html.write_pdf(target='/tmp/mypdf.pdf')
        fs = FileSystemStorage('/tmp')
        with fs.open('mypdf.pdf') as pdf:
            
            response = HttpResponse(pdf, content_type='application/pdf')
            response['Content-Disposition'] = 'attachment;filename="report.pdf"'
            
            return response
        
        return reponse

class read_s3_contents(mixins.ListModelMixin,viewsets.GenericViewSet):
  
    def get_queryset(self):
        self.key = self.request.query_params.get('key', None)
        return self.key

    def list(self, request):
        s3 = boto3.resource('s3',aws_access_key_id=access_key,aws_secret_access_key=secret_access_key )
        key = self.get_queryset()
        print(key)
        obj = s3.Object(bucket_name='qzense-report', key=key)
        response = obj.get()
        data = response['Body'].read()
       
        return HttpResponse(data, content_type='application/pdf')
        

# class get_s3_report(mixins.ListModelMixin,viewsets.GenericViewSet):

#     queryset = WarehouseData.objects.values_list('warehouse_id','date','fruit','variety','brix','device_id','action','status','vendor_code__vendor_code')
#     permission_classes = (AllowAny,)
#     renderer_classes = (WarehouseDataJSONRenderer,)
  
    
#     def get_queryset(self, **kwargs):
       
#          queryset = self.queryset
#          if not self.request.user.is_superuser:
#              try:
#                  warehouse = Warehouses.objects.get(user=self.request.user)
#              except Warehouses.DoesNotExist:
#                  return WarehouseData.objects.none()
#              queryset = queryset.filter(warehouse_id=warehouse.warehouse_id)
#          else:
#              warehouse_id = self.request.query_params.get('warehouse_id', None)
#              if warehouse_id is not None:
#                  queryset = queryset.filter(warehouse_id=warehouse_id)
#                  print(warehouse_id)
#              return warehouse_id

#     def list(self, request):
#         s3 = boto3.resource('s3',aws_access_key_id=access_key,aws_secret_access_key=secret_access_key)
#         my_bucket = s3.Bucket('qzense-report')
#         r = {}
        
#         # print("USER OF DATA>>>>>>>>>>>>>>>>>>>>>> ",warehouse_id)
#         for my_bucket_object in my_bucket.objects.filter(Prefix='UD001/'):    
#              r[f'{my_bucket_object.key.split("/")[-4]}']={}
#              for my_bucket_object in my_bucket.objects.filter(Prefix=f'UD001/'):
#                 r[my_bucket_object.key.split("/")[-4]][my_bucket_object.key.split("/")[-3]]={}
#                 for my_bucket_object in my_bucket.objects.filter(Prefix=f'UD001/{my_bucket_object.key.split("/")[-3]}/'):
#                     r[my_bucket_object.key.split("/")[-4]][my_bucket_object.key.split("/")[-3]][my_bucket_object.key.split("/")[-2]]={}
#                     for my_bucket_object in my_bucket.objects.filter(Prefix=f'UD001/{my_bucket_object.key.split("/")[-3]}/{my_bucket_object.key.split("/")[-2]}/'):
#                         r[my_bucket_object.key.split("/")[-4]][my_bucket_object.key.split("/")[-3]][my_bucket_object.key.split("/")[-2]][my_bucket_object.key.split("/")[-1]]=my_bucket_object.key
#         print(r)     
       
#         return HttpResponse(r, content_type='application/pdf')

def getS3Report(request):
    s3 = boto3.resource('s3',aws_access_key_id=access_key,aws_secret_access_key=secret_access_key)
    my_bucket = s3.Bucket('qzense-report')
    # r = {}
    r = []
    arr=[]
    for my_bucket_object in my_bucket.objects.filter(Prefix='UD001/'):  
        # print('#########',my_bucket_object.key)

        [_,year,month,*rest]=my_bucket_object.key.split("/")
        r.append({"key":my_bucket_object.key,"year":int(year),"month":int(month)} )
        # r.append({"year":my_bucket_object.key})
        # r.append({"month":my_bucket_object.key})
    # print("USER OF DATA>>>>>>>>>>>>>>>>>>>>>> ",request.query_params.get('w',None))
    # for my_bucket_object in my_bucket.objects.filter(Prefix='UD001/'):    
    #      r[f'{my_bucket_object.key.split("/")[-4]}']={}
    #      for my_bucket_object in my_bucket.objects.filter(Prefix=f'UD001/'):
    #         r[my_bucket_object.key.split("/")[-4]][my_bucket_object.key.split("/")[-3]]={}
    #         for my_bucket_object in my_bucket.objects.filter(Prefix=f'UD001/{my_bucket_object.key.split("/")[-3]}/'):
    #             r[my_bucket_object.key.split("/")[-4]][my_bucket_object.key.split("/")[-3]][my_bucket_object.key.split("/")[-2]]={}
    #             for my_bucket_object in my_bucket.objects.filter(Prefix=f'UD001/{my_bucket_object.key.split("/")[-3]}/{my_bucket_object.key.split("/")[-2]}/'):
    #                 r[my_bucket_object.key.split("/")[-4]][my_bucket_object.key.split("/")[-3]][my_bucket_object.key.split("/")[-2]][my_bucket_object.key.split("/")[-1]]=my_bucket_object.key
    # print(r)     
    return HttpResponse(json.dumps(r),content_type='application/json')


class MeatDataViewSet(mixins.ListModelMixin,viewsets.GenericViewSet):
    """
    list:
    Return a list of all the warehouse data with given offset and limit.

    """
    schema = WarehouseDataSchema()
    queryset = QscanMeat.objects.all()
    permission_classes = (AllowAny,)
    renderer_classes = (WarehouseDataJSONRenderer,)
    serializer_class = MeatDataSerializer

    def get_queryset(self):
        queryset = self.queryset
        if not self.request.user.is_superuser:
            try:
                warehouse = Warehouses.objects.get(user=self.request.user)
            except Warehouses.DoesNotExist:
                return WarehouseData.objects.none()
            queryset = queryset.filter(warehouse_id=warehouse.warehouse_id)
        else:
            warehouse_id = self.request.query_params.get('warehouse_id', None)
            if warehouse_id is not None:
                queryset = queryset.filter(warehouse_id=warehouse_id)

        device = self.request.query_params.get('device', None)
        if device is not None:
            queryset = queryset.filter(device=device)

        meat = self.request.query_params.get('meat', None)
        if meat is not None:
            queryset = queryset.filter(meat=meat)

        species = self.request.query_params.get('species', None)
        if species is not None:
            queryset = queryset.filter(species=species)

        start = self.request.query_params.get('start', None)
        end = self.request.query_params.get('end', None)
        if start is not None and end is not None:
            queryset = queryset.annotate(timedate=Concat('date','timestamp'))
            """ creates a virtual column timedate with time and date in it -- date and time filter"""
            queryset = queryset.filter(timedate__range=(start, end))

        return queryset


    def list(self, request):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.serializer_class(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


class MeatHeadersRetrieveAPIView(generics.RetrieveAPIView):
    """
    get:
    Return a list of all headers of table.

    """
    permission_classes = (AllowAny,)
    renderer_classes = (WarehouseDataHeadersJSONRenderer,)
    pagination_class = None

    def retrieve(self, request):
        labels = {}

        for field in MeatDataSerializer.Meta.model._meta.get_fields():
            if field.name in MeatDataSerializer.Meta.fields:
                labels[field.name] = field.verbose_name

        for field in MeatDataSerializer.Meta.fields:
            if labels.get(field, None) is None:
                labels[field] = field

        return Response({'results': labels})

