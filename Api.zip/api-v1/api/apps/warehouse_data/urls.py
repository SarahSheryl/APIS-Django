from django.urls import include, path

from rest_framework.routers import DefaultRouter

from .views import (read_s3_contents,getS3Report,CustomizedPdf,GeneratePdf,WarehouseDataViewSet, WarehouseDataHeadersRetrieveAPIView,GenerateReport,MeatDataViewSet,MeatHeadersRetrieveAPIView)

router = DefaultRouter(trailing_slash=False)
router.register('warehouse-data', WarehouseDataViewSet)
router.register('Qscan-Meat',MeatDataViewSet)

urlpatterns = [
     path('', include(router.urls)),
     path('warehouse-data/headers', WarehouseDataHeadersRetrieveAPIView.as_view()),
     path('Qscan-Meat/headers',MeatHeadersRetrieveAPIView.as_view()),
     path('generate-report',GenerateReport.as_view({'get': 'list'})),
     path('download',GeneratePdf.as_view({'get': 'list'}),name='generatepdf'),
     path('customdownload',GeneratePdf.as_view({'get': 'list'})),
     path('downloadfroms3', read_s3_contents.as_view({'get': 'list'})),
     path('gets3folders',getS3Report),
     # path('gets3folders',get_s3_report.as_view({'get': 'list'}))
     
]
