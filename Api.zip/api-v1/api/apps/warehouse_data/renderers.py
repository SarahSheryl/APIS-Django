from api.apps.core.renderers import ApiJSONRenderer

class WarehouseDataJSONRenderer(ApiJSONRenderer):
    object_label = 'data'
    pagination_object_label = 'data'
    pagination_count_label = 'data_count'

class WarehouseDataHeadersJSONRenderer(ApiJSONRenderer):
    object_label = 'headers'
    pagination_object_label = 'headers'
    pagination_count_label = 'headers_count'