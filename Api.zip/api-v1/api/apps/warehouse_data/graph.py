from quickchart import QuickChart, QuickChartFunction

     
        

def PieChart(data,labels,title,backgroundcolor):
    qc = QuickChart()
    qc.width = 450
    qc.height = 400
    qc.device_pixel_ratio = 2.0
    # Config can be set as a string or as a nested dict
    qc.config = {
                "type": "outlabeledPie",
                "data": {
                "labels": labels,
                "datasets": [{
                            "backgroundColor": backgroundcolor,
                            "data": data
                            }]
                },
            "options": {
                'title': {
      'display': True,
      'text':title,
      'fontSize':24
    },
    "plugins": {
      "legend": False,
      "outlabels": {
        "text": "%l:%p \n Qty:%v",
        "color": "white",
        "stretch": 30,
        "lineWidth":1,
        "display": QuickChartFunction ('''function(context) {
            var index = context.dataIndex;
            var value = context.dataset.data[index];
            return value > 0 ? true : false     
           }'''),
        "font": {
          "resizable": True,
          "minSize": 15,
          "maxSize": 20
        }
      }
    }
  }
}

# You can get the chart URL...
    pieurl = qc.get_url()

    return pieurl


def StackedBarChart(labels,acceptf,rejectf,title):
  qc = QuickChart()
  qc.width = 400
  qc.height = 300

  qc.device_pixel_ratio = 2.0
# Config can be set as a string or as a nested dict
  qc.config = {
   'type': 'horizontalBar',
   'data': {
    'labels': labels,
    'datasets': [
      {
        'label': 'Accept',
        'backgroundColor': 'rgb(31,119,180)',
        'data': acceptf,
      },
      {
        'label': 'Reject',
        'backgroundColor': 'rgb(255,127,14)',
        'data': rejectf,
      },
   
    ],
  },
  'options': {
    'title': {
      'display': True,
      'text':title,

    },
    'scales': {
      'xAxes': [
        {
          'stacked': True,
          'gridLines': {
                'drawOnChartArea': False
            }

        },
      ],
      'yAxes': [
        {
          'stacked': True,
          'gridLines': {
              'drawOnChartArea': False
            }
        },
      ],
    },
  },
}

# You can get the chart URL...
  barurl = qc.get_url()
  return barurl



def lineChart(title,label,total,acceptedbrix,totallabel,Acceptedlabel,acceptedbrixpercent):
  qc = QuickChart()
  qc.width = 700
  qc.height = 500

# Config can be set as a string or as a nested dict
  qc.config = {
  'type': 'line',
  'data': {
    'labels': label,
    'datasets': [
      {
        'label': 'Total - '+str(totallabel) ,
        'backgroundColor': 'rgb(255, 99, 132)',
        'borderColor': 'black',
        'data': total,
        'fill': False,
        'lineTension':0.4,
        'pointRadius':0,
        'borderWidth':1
      },
      {
        'label':f'Accepted - {Acceptedlabel} ({acceptedbrixpercent}%)',
        'fill': True,
        'backgroundColor': 'rgba(149, 198, 35, 1)',
        'borderColor': 'rgba(149, 198, 35, 1)',
        'data': acceptedbrix,
        'lineTension':0.4,
        'pointRadius':0,
        'borderWidth':0

      },
    ],
  },
  'options': {
    'title': {
      'display': True,
      'text': title,
      'fontSize':25
    },
    'legend': {
            'labels': {
                # // This more specific font property overrides the global property
                'fontColor': 'black',
                'fontSize':20
            }
        },
            'scales': {
      'xAxes': [
        {
          'scaleLabel': {
                          'display': True,
                            'labelString': 'Brix',
                           
                            'fontSize':20
                            },
          'gridLines': {
                'drawOnChartArea': False
            }

        },
      ],
      'yAxes': [
        {
           'scaleLabel': {
                                  'display': True,
                                  'labelString': 'Qty',
                                 
                                    'fontSize':20
                                },
          'gridLines': {
              'drawOnChartArea': True
            }
        },
      ],
    },
  },
}
  line = qc.get_url()
  return line


