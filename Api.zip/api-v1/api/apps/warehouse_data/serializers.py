from rest_framework import serializers
from .models import WarehouseData,QscanMeat
from api.apps.devices.models import Devices
from api.apps.vendor.relations import VendorRelatedField

class WarehouseDataSerializer(serializers.ModelSerializer):
    device_type = serializers.SerializerMethodField(read_only=True)
    vendor_code = VendorRelatedField(many=False,required=True)
    
    """temperature = serializers.SerializerMethodField(read_only=True)
    humidity = serializers.SerializerMethodField(read_only=True)
    CH4 = serializers.SerializerMethodField(read_only=True)
    CO2 = serializers.SerializerMethodField(read_only=True) """

    def get_device_type(self, value):
        return value.device.device_type.device_type

    """ def get_temperature(self, value):
        return value.sensor_data.get('temperature', None)

    def get_humidity(self, value):
        return value.sensor_data.get('humidity', None)

    def get_CH4(self, value):
        return value.sensor_data.get('CH4',None)

    def get_CO2(self, value):
        return value.sensor_data.get('CO2',None) """

    class Meta:
        model = WarehouseData
        fields = (
                    'warehouse_id',
                    'timestamp',
                    'date',
                    'fruit',
                    'variety',
                    'device',
                    'device_type',
                    'brix',
                    'status',
                    'batch_number',
                     'refractometer_brix',
                     'action',
                     'vendor_code',
                     'wavelength_610nm',
                     'wavelength_680nm',
                     'wavelength_730nm',
                     'wavelength_760nm',
                     'wavelength_810nm',
                     'wavelength_860nm',
                     'selflife',
                     'commodity',
                     'commodity_variety'

                )

class GenerateDataSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = WarehouseData
        fields = '__all__'


class MeatDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = QscanMeat
        fields = (
                 'id',
                 'timestamp',
                 'date',
                 'warehouse_id',
                 'device',
                'temperature',
                'humidity',
                'carbon_dioxide',
                 'oxygen',
                'hydrogen_sulfide',
                 'ammonia',
                 'voc',
                 'goodbad',
                 'mac_id',
                 'meat',
                'species',
                'vendor_code'
                
    )