from django.urls import include, path

from rest_framework.routers import DefaultRouter

from .views import (WarehousesViewSet)

from .views import UserProfileListCreateView, userProfileDetailView


router = DefaultRouter(trailing_slash=False)
router.register('warehouses', WarehousesViewSet)

urlpatterns = [
     path('', include(router.urls)),
      #gets all user profiles and create a new profile
    path("all-profiles",UserProfileListCreateView.as_view(),name="all-profiles"),
   # retrieves profile details of the currently logged in user
     path("profile/",userProfileDetailView.as_view(),name="profile"),
]
