from django.db import models
from django.contrib.postgres.fields import JSONField

class Warehouses(models.Model):
    user = models.ForeignKey('authentication.User', related_name='warehouses', on_delete=models.CASCADE)
    warehouse_id = models.CharField(unique=False, max_length=100)
    service = models.JSONField(blank=True,null=True)

    class Meta:
        # managed = False
        ordering = ['-id']
        db_table = 'warehouses'
        verbose_name_plural = "warehouses"

    def __str__(self):
        return f"{self.warehouse_id} {self.user.username} {self.service}"