from rest_framework import serializers

from .models import Warehouses

class WarehousesRelatedField(serializers.RelatedField):
    def get_queryset(self):
        return Warehouses.objects.all()

    def to_internal_value(self, data):
        try:
            return Warehouses.objects.get(id=data)
        except Warehouses.DoesNotExist:
            raise serializers.ValidationError(
                'Warehouse with the specified warehouse id does not exist.'
            )

    def to_representation(self, value):
        return value.warehouse_id
