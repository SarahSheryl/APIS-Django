from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth import get_user_model
User = get_user_model()
from djoser.signals import user_activated
from api.apps.warehouses.models import Warehouses


@receiver(user_activated)
def create_profile(user,request,**kwargs):
    Warehouses.objects.create(user=user) 