from django.apps import AppConfig


class WarehousesConfig(AppConfig):
    name = 'api.apps.warehouses'

    def ready(self):
        import api.apps.warehouses.signals