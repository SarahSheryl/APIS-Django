from django.contrib import admin
from .models import Warehouses

admin.site.register(Warehouses)