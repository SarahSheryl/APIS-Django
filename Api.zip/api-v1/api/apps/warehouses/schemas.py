from rest_framework.schemas import AutoSchema

import coreapi
import coreschema
import json

class WarehousesSchema(AutoSchema):

    def get_serializer_fields(self, path, method):
        return []

    def get_manual_fields(self, path, method):
        custom_fields = []
        if "{warehouse_id}" in path:
            custom_fields.append(
                coreapi.Field(
                    "warehouse_id",
                    required=True,
                    location="path",
                    schema=coreschema.String(description='Warehouse_id of selected warehouse.')
                ),
            )

        if method.upper() in ['POST', 'PUT']:
            data =  {
                "warehouse": {
                    "warehouse_id": "required",
                }
            }

            custom_fields.append(
                coreapi.Field(
                    "warehouse",
                    required=True,
                    location="body",
                    schema=coreschema.Object(description=
                        '<pre>'+json.dumps(data, indent=4)+'</pre>')
                ),
            )

        return self._manual_fields + custom_fields