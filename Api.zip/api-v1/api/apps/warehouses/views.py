from rest_framework import generics, mixins, status, viewsets
from rest_framework.exceptions import NotFound
from rest_framework.permissions import (
    AllowAny, IsAuthenticated, IsAuthenticatedOrReadOnly
)


from .models import Warehouses
from api.apps.authentication.models import User
from .renderers import WarehousesJSONRenderer
from .serializers import WarehousesSerializer
from django.shortcuts import get_object_or_404
from .schemas import WarehousesSchema
from .permissions import IsOwnerProfileOrReadOnly
from rest_framework.response import Response

class WarehousesViewSet(mixins.ListModelMixin,
                    #  mixins.CreateModelMixin, 
                     mixins.RetrieveModelMixin,
                     mixins.DestroyModelMixin,
                     viewsets.GenericViewSet):
    """
    list:
    Return a list of all the warehouses.

    retrieve:
    Return the given warehouse.

    update:
    Update the given warehouse with new attributes.

    destroy:
    Delete the given warehouse.

    """
    schema = WarehousesSchema()
    #lookup_field = 'warehouse_id'
    queryset = Warehouses.objects.select_related('user')
    permission_classes = (IsAuthenticated,)
    #renderer_classes = (WarehousesJSONRenderer,)
    serializer_class = WarehousesSerializer

    def get_queryset(self):
        queryset = self.queryset
        if not self.request.user.is_superuser:
            # print('self.request.user',self.request.user)
            queryset = queryset.filter(user=self.request.user)
          
        warehouse_id = self.request.query_params.get('warehouse_id', None)
        print('self.request.user',warehouse_id)
        if warehouse_id is not None:
            queryset = queryset.get(warehouse_id=warehouse_id)
        return queryset

    # def create(self, request):
    #     serializer_context = {
    #         'user': request.user
    #     }
    #     serializer_data = request.data.get('warehouse', {})
    #     username = serializer_data.pop('username', None)
    #     if request.user.is_superuser and username:
    #         try:
    #             serializer_context['user'] = User.objects.get(username=username)
    #         except User.DoesNotExist:
    #             raise NotFound('A user with this username does not exist.')
        
    #     serializer = self.serializer_class(
    #         data=serializer_data,
    #         context=serializer_context
    #     )
    #     serializer.is_valid(raise_exception=True)
    #     serializer.save()
        
    #     return Response(serializer.data, status=status.HTTP_201_CREATED)

    def list(self, request):
        serializer_context = {'request': request}
        if self.request.user.is_superuser:
            data = Warehouses.objects.all()
        else:
            data = Warehouses.objects.filter(user=request.user)

        serializer = self.serializer_class(
            data,
            context=serializer_context,
            many=True
        )
        return Response({
            'results': serializer.data,
            'count': data.count()
        })

    def retrieve(self, request, warehouse_id):
        serializer_context = {
            'request': request
        }

        try:
            filters = {'warehouse_id': warehouse_id}
            if not request.user.is_superuser:
                filters['user'] = request.user
            serializer_instance = self.queryset.get(**filters)
        except Warehouses.DoesNotExist:
            raise NotFound('A warehouse with this warehouse id does not exist.')

        serializer = self.serializer_class(
            serializer_instance,
            context=serializer_context
        )

        return Response(serializer.data, status=status.HTTP_200_OK)


    def update(self, request, warehouse_id):
        serializer_context = {
            'request': request
        }

        try:
            serializer_instance = self.queryset.get(warehouse_id=warehouse_id)
        except Warehouses.DoesNotExist:
            raise NotFound('A warehouse with this warehouse id does not exist.')
            
        serializer_data = request.data.get('warehouse', {})

        serializer = self.serializer_class(
            serializer_instance, 
            context=serializer_context,
            data=serializer_data, 
            partial=True
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data, status=status.HTTP_200_OK)

    def destroy(self, request, warehouse_id=None):
        try:
            warehouse = Warehouses.objects.get(warehouse_id=warehouse_id)
        except Warehouses.DoesNotExist:
            raise NotFound('A warehouse with this warehouse id does not exist.')

        warehouse.delete()

        return Response(None, status=status.HTTP_204_NO_CONTENT)


class WarehouseListCreateAPIView(generics.ListCreateAPIView):
    lookup_field = 'warehouse_id'
    queryset = Warehouses.objects.select_related('user')
    permission_classes = (AllowAny,)
    #renderer_classes = (WarehousesJSONRenderer,)
    serializer_class = WarehousesSerializer

class UserProfileListCreateView(generics.ListCreateAPIView):
    queryset=Warehouses.objects.all()
    serializer_class=WarehousesSerializer
    permission_classes=[IsAuthenticated]

    def perform_create(self, serializer):
        user=self.request.user
        serializer.save(user=user)


class userProfileDetailView(generics.RetrieveUpdateDestroyAPIView):
    #lookup_field='user_id'
    queryset=Warehouses.objects.all()
    serializer_class=WarehousesSerializer
    permission_classes=[IsOwnerProfileOrReadOnly,IsAuthenticated]

    def get_object(self):
        queryset = self.get_queryset()
        obj = get_object_or_404(queryset, user=self.request.user)
        return obj
