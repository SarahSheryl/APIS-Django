from rest_framework import serializers
from .models import Warehouses

#from api.apps.authentication.serializers import UserSerializer


class WarehousesSerializer(serializers.ModelSerializer):
    user = serializers.StringRelatedField(read_only=True)
    class Meta:
        model = Warehouses
        fields = (
                    'id',
                    'user',
                    'warehouse_id',
                    'service'
                )
"""
    def create(self, validated_data):
        user = self.context['user']
        return Warehouses.objects.create(user=user, **validated_data)

    def to_representation(self, obj):
        return {'user': obj.user.username, 'warehouse_id': obj.warehouse_id}
"""