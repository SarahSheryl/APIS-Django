from api.apps.core.renderers import ApiJSONRenderer

class WarehousesJSONRenderer(ApiJSONRenderer):
    object_label = 'warehouses'
    pagination_object_label = 'warehouses'
    pagination_count_label = 'warehouses_count'