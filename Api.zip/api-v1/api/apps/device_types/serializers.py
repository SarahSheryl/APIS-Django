from rest_framework import serializers
from .models import DeviceTypes


class DeviceTypesSerializer(serializers.ModelSerializer):

    class Meta:
        model = DeviceTypes
        fields = (
            'device_type',
        )

    def to_representation(self, obj):
        return obj.device_type