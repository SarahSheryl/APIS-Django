from rest_framework import serializers

from .models import DeviceTypes

class DeviceTypesRelatedField(serializers.RelatedField):
    def get_queryset(self):
        return DeviceTypes.objects.all()

    def to_internal_value(self, device_type):
        try:
            return DeviceTypes.objects.get(device_type=device_type)
        except DeviceTypes.DoesNotExist:
            raise serializers.ValidationError(
                'Device type does not exist.'
            )

    def to_representation(self, value):
        return value.device_type
