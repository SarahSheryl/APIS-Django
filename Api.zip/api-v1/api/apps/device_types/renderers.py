from api.apps.core.renderers import ApiJSONRenderer

class DeviceTypesJSONRenderer(ApiJSONRenderer):
    object_label = 'device_types'
    pagination_object_label = 'device_types'
    pagination_count_label = 'types_count'