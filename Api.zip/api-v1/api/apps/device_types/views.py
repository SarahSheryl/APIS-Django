from rest_framework import generics, mixins, status, viewsets
from rest_framework.exceptions import NotFound
from rest_framework.permissions import (
    AllowAny
)
from rest_framework.response import Response


from .models import DeviceTypes
from .renderers import DeviceTypesJSONRenderer
from .serializers import DeviceTypesSerializer

from .schemas import DeviceTypesSchema


class DeviceTypesViewSet(mixins.CreateModelMixin,
                         mixins.ListModelMixin,
                         mixins.RetrieveModelMixin,
                         mixins.DestroyModelMixin,
                         viewsets.GenericViewSet):
    """
    create:
    Create a new device type.

    list:
    Return a list of all the device types.

    update:
    Update the given device type.

    retrieve:
    Return the given device type.

    destroy:
    Delete the given device type.

    """
    schema = DeviceTypesSchema()
    lookup_field = 'device_type'
    queryset = DeviceTypes.objects.all()
    permission_classes = (AllowAny,)
    renderer_classes = (DeviceTypesJSONRenderer,)
    serializer_class = DeviceTypesSerializer
    pagination_class = None

    def get_queryset(self):
        return self.queryset

    def create(self, request):
        serializer_data = request.data.get('device_type', {})

        serializer = self.serializer_class(
            data=serializer_data,
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def list(self, request):
        data = DeviceTypes.objects.all()

        serializer = self.serializer_class(
            data,
            many=True
        )
        return Response({
            'results': serializer.data,
            'count': data.count()
        })

    def retrieve(self, request, device_id=None):
        serializer_context = {'request': request}

        try:
            serializer_instance = self.queryset.get(device_type=device_type)
        except DeviceTypes.DoesNotExist:
            raise NotFound('This device type does not exist.')

        serializer = self.serializer_class(
            serializer_instance,
            context=serializer_context
        )

        return Response(serializer.data, status=status.HTTP_200_OK)

    def update(self, request, device_type=None):
        serializer_context = {
            'request': request
        }

        try:
            serializer_instance = self.queryset.get(device_type=device_type)
        except Devices.DoesNotExist:
            raise NotFound('A device with this device id does not exist.')
            
        serializer_data = request.data.get('device_type', {})
        
        serializer = self.serializer_class(
            serializer_instance, 
            context=serializer_context,
            data=serializer_data, 
            partial=True
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data, status=status.HTTP_200_OK)

    def destroy(self, request, device_type=None):
        try:
            device_type = Devices.objects.get(device_type=device_type)
        except DeviceTypes.DoesNotExist:
            raise NotFound('This device type does not exist.')

        device_type.delete()

        return Response(None, status=status.HTTP_204_NO_CONTENT)
