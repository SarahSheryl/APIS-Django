from rest_framework.schemas import AutoSchema

import coreapi
import coreschema
import json


class DeviceTypesSchema(AutoSchema):

    def get_serializer_fields(self, path, method):
        return []

    def get_manual_fields(self, path, method):
        custom_fields = []
        if "{device_type}" in path:
            custom_fields.append(
                coreapi.Field(
                    "device_type",
                    required=True,
                    location="path",
                    schema=coreschema.Object(description='Device type'),
                ),
            )

        if method.upper() in ['POST', 'PUT']:
            data = {
                "device_type": {
                    "device_type": "required",
                }
            }

            custom_fields.append(
                coreapi.Field(
                    "device_type",
                    required=True,
                    location="body",
                    schema=coreschema.Object(
                        description='<pre>'+json.dumps(data, indent=4)+'</pre>')
                ),
            )

        return self._manual_fields + custom_fields
