from django.db import models


class DeviceTypes(models.Model):
    device_type = models.TextField()

    class Meta:
        ordering = ['-id']
        # Comment out managed = False when changing schema
        # managed = False
        db_table = 'device_types'
        verbose_name_plural = 'Device types'

    def __str__(self):
        return f"{self.device_type}"
