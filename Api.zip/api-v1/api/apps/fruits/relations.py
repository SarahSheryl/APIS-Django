from rest_framework import serializers

from .models import Fruits, FruitVarieties

class FruitVarietiesRelatedField(serializers.RelatedField):
    def get_queryset(self):
        return FruitVarieties.objects.all()

    def to_internal_value(self, data):
        try:
            return FruitVarieties.objects.get(id=data)
        except FruitVarieties.DoesNotExist:
            raise serializers.ValidationError(
                'Fruit with the specified variety does not exist.'
            )

    def to_representation(self, value):
        return value.variety

class FruitRelatedField(serializers.RelatedField):
    def get_queryset(self):
        return Fruits.objects.all()

    def to_internal_value(self,fruit):
        try:
            return Fruits.objects.get(fruit_name=fruit)
        except Fruits.DoesNotExist:
            raise serializers.ValidationError(
                'Fruit with the specified variety does not exist.'
            )

    def to_representation(self, value):
        return value.fruit_name
