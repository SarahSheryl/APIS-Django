from rest_framework import serializers 
from .models import Fruits, FruitVarieties
from django.utils.text import slugify
from itertools import chain

class FruitVarietiesSerializer(serializers.ModelSerializer):

    class Meta:
        model = FruitVarieties
        fields = (
                    'id',
                    'variety',
                )
    
    def create(self, validated_data):
        fruit = self.context['fruit']
        return FruitVarieties.objects.create(
           fruit=fruit, **validated_data)

    def to_representation(self, obj):
        v = [obj.id,obj.variety]
        return v



class FruitsSerializer(serializers.ModelSerializer):
    varieties = FruitVarietiesSerializer(many=True, read_only=True)
    fruit_slug = serializers.SerializerMethodField(read_only=True)

    def get_fruit_slug(self, instance):
        return slugify(instance.fruit_name).upper()

    class Meta:
        model = Fruits
        fields = (
                    'id',
                    'fruit_name',
                    'color',
                    'fruit_slug',
                    'varieties',
                )

    def create(self, validated_data):
        varieties = self.context['varieties']
        fruit = Fruits.objects.create(**validated_data)
        for variety in varieties:
            FruitVarieties.objects.create(fruit=fruit, variety=variety)
        return fruit