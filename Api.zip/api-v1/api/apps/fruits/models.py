from django.db import models
from colorfield.fields import ColorField

class Fruits(models.Model):
    fruit_name = models.TextField(unique=True)
    color = ColorField(default='#FF0000')

    class Meta:
        # Comment out managed = False when changing schema
        # managed = False
        ordering = ['-id']
        db_table = 'fruits'
        verbose_name_plural = "fruits"

    def __str__(self):
        return self.fruit_name

class FruitVarieties(models.Model):
    fruit = models.ForeignKey('fruits.Fruits', related_name='varieties', on_delete=models.CASCADE)
    variety = models.TextField()

    class Meta:
       # Comment out managed = False when changing schema
        #managed = False 
        ordering = ['-id']
        db_table = 'fruit_varieties'
        verbose_name_plural = "fruit varieties"

    def __str__(self):
        return f"{self.fruit.fruit_name} {self.variety}"
