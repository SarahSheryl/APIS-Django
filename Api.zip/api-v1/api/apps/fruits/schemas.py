from rest_framework.schemas import AutoSchema

import coreapi
import coreschema
import json

class FruitsSchema(AutoSchema):

    def get_serializer_fields(self, path, method):
        return []

    def get_manual_fields(self, path, method):
        custom_fields = []
        if "{fruit_slug}" in path:
            custom_fields.append(
                coreapi.Field(
                    "fruit_slug",
                    required=True,
                    location="path",
                    schema=coreschema.String(description='Fruit name formatted as slug.')
                ),
            )

        if method.upper() in ['POST', 'PUT']:
            data =  {
                "fruit": {
                    "fruit_name": "required",
                    "color": "required",
                    "varieties": [
                        "atleast 1 variety",
                        "...",
                    ],
                }
            }

            if method.upper() == "PUT":
                data =  {
                    "fruit": {
                        "fruit_name": "optional",
                        "color": "optional",
                    }
                }

            custom_fields.append(
                coreapi.Field(
                    "fruit",
                    required=True,
                    location="body",
                    schema=coreschema.Object(description=
                        '<pre>'+json.dumps(data, indent=4)+'</pre>')
                ),
            )

        return self._manual_fields + custom_fields

class FruitVarietiesSchema(AutoSchema):

    def get_serializer_fields(self, path, method):
        return []

    def get_manual_fields(self, path, method):
        custom_fields = []
        if "{fruit_slug}" in path:
            custom_fields.append(
                coreapi.Field(
                    "fruit_slug",
                    required=True,
                    location="path",
                    schema=coreschema.Object(description='Fruit name formatted as slug.')
                ),
            )

        if "{variety_slug}" in path:
            custom_fields.append(
                coreapi.Field(
                    "variety_slug",
                    required=True,
                    location="path",
                    schema=coreschema.String(description='Variety formatted as slug.')
                ),
            )

        if method.upper() in ['POST', 'DELETE']:
            data =  {
                "fruit": {
                    "variety": "requried",
                }
            }

            custom_fields.append(
                coreapi.Field(
                    "variety",
                    required=True,
                    location="body",
                    schema=coreschema.Object(description=
                        '<pre>'+json.dumps(data, indent=4)+'</pre>')
                ),
            )

        return self._manual_fields + custom_fields