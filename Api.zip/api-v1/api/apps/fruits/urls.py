
from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import (
    FruitsViewSet, FruitVarietiesCreateAPIView, FruitVarietiesDestroyAPIView
)

router = DefaultRouter(trailing_slash=False)
router.register('fruits', FruitsViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('fruits/<slug:fruit_slug>/variety', FruitVarietiesCreateAPIView.as_view()),
    path('fruits/<slug:fruit_slug>/variety/<slug:variety_slug>', FruitVarietiesDestroyAPIView.as_view()),
]
