from rest_framework import generics, mixins, status, viewsets
from rest_framework.exceptions import NotFound
from rest_framework.permissions import (
    AllowAny, IsAdminUser
)
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Fruits, FruitVarieties
from api.apps.core.permissions import IsAdminUserOrReadOnly
from .renderers import FruitsJSONRenderer, FruitVarietiesJSONRenderer
from .serializers import FruitsSerializer, FruitVarietiesSerializer

from .schemas import (FruitsSchema, FruitVarietiesSchema)

class FruitsViewSet(mixins.CreateModelMixin, 
                     mixins.ListModelMixin,
                     mixins.RetrieveModelMixin,
                     mixins.DestroyModelMixin,
                     viewsets.GenericViewSet):
    """
    create:
    Create a new fruit.

    list:
    Return a list of all the fruits along with its varieties.

    retrieve:
    Return the given fruit.

    update:
    Update the given fruit with new attributes.

    destroy:
    Delete the given fruit.

    """
    schema = FruitsSchema()
    lookup_field = 'fruit_slug'
    queryset = Fruits.objects.all()
    permission_classes = (IsAdminUserOrReadOnly,)
    renderer_classes = (FruitsJSONRenderer,)
    serializer_class = FruitsSerializer

    def get_queryset(self):
        queryset = self.queryset
        fruit_slug = self.request.query_params.get('fruit_slug', None)
        if fruit_slug is not None:
            fruit_name = fruit_slug.replace('-', ' ')
            if fruit_name is not None:
                queryset = queryset.filter(fruit_name=fruit_name)
        return queryset

    def create(self, request):
        serializer_context = {
            'request': request
        }
        serializer_data = request.data.get('fruit', {})
        varieties = serializer_data.pop('varieties', None)
        if not varieties:
            raise NotFound('Atleast one variety has to be included.')
        
        if not all(isinstance(item, str) for item in varieties):
            raise NotFound('All varieties have to be strings')

        serializer_context['varieties'] = varieties
        serializer = self.serializer_class(
            data=serializer_data, context=serializer_context
        )
      
        serializer.is_valid(raise_exception=True)
        serializer.save()
        
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def list(self, request):
        serializer_context = {'request': request}
        data = Fruits.objects.all()

        serializer = self.serializer_class(
            data,
            context=serializer_context,
            many=True
        )
        return Response({
            'results': serializer.data,
            'count': data.count()
        })

    def retrieve(self, request, fruit_slug=None):
        serializer_context = {'request': request}
        fruit_name = fruit_slug.replace('-', ' ')
        try:
            serializer_instance = self.queryset.get(fruit_name=fruit_name)
        except Fruits.DoesNotExist:
            raise NotFound('A fruit with this name does not exist.')

        serializer = self.serializer_class(
            serializer_instance,
            context=serializer_context
        )

        return Response(serializer.data, status=status.HTTP_200_OK)


    def update(self, request, fruit_slug=None):
        serializer_context = {'request': request}
        
        fruit_name = fruit_slug.replace('-', ' ')
        try:
            serializer_instance = self.queryset.get(fruit_name=fruit_name)
        except Fruits.DoesNotExist:
            raise NotFound('A fruit with this name does not exist.')
            
        serializer_data = request.data.get('fruit', {})

        serializer = self.serializer_class(
            serializer_instance, 
            context=serializer_context,
            data=serializer_data, 
            partial=True
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data, status=status.HTTP_200_OK)

    def destroy(self, request, fruit_slug=None):
        fruit_name = fruit_slug.replace('-', ' ')
        try:
            fruit = Fruits.objects.get(fruit_name=fruit_name)
        except Fruits.DoesNotExist:
            raise NotFound('A fruit with this name does not exist.')

        fruit.delete()

        return Response(None, status=status.HTTP_204_NO_CONTENT)


class FruitVarietiesCreateAPIView(generics.CreateAPIView):
    """
    post:
    Add a variety to the given fruit.

    """
    schema = FruitVarietiesSchema()
    lookup_field = 'variety_slug'
    permission_classes = (IsAdminUserOrReadOnly,)
    queryset = FruitVarieties.objects.select_related('fruit')
    renderer_classes = (FruitVarietiesJSONRenderer,)
    serializer_class = FruitVarietiesSerializer

    def create(self, request, fruit_slug=None):
        
        data = request.data.get('fruit', {})
        fruit_name = fruit_slug.replace('-', ' ')
        context = {}
        try:
            context['fruit'] = Fruits.objects.get(fruit_name=fruit_name)
        except Fruits.DoesNotExist:
            raise NotFound('A fruit with this name does not exist.')

        serializer = self.serializer_class(data=data, context=context)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data, status=status.HTTP_201_CREATED)

class FruitVarietiesDestroyAPIView(generics.DestroyAPIView):
    """
    delete:
    Delete the given variety of the fruit.
    """
    lookup_field = 'variety_slug'
    schema = FruitVarietiesSchema()
    permission_classes = (IsAdminUser,)
    queryset = FruitVarieties.objects.all()

    def destroy(self, request, fruit_slug=None, variety_slug=None):
        variety_name = variety_slug.replace('-', ' ')

        try:
            variety = FruitVarieties.objects.get(variety=variety_name)
        except FruitVarieties.DoesNotExist:
            raise NotFound('A fruit with this variety does not exist.')
        variety.delete()

        return Response(None, status=status.HTTP_204_NO_CONTENT)
