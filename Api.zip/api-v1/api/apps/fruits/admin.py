from django.contrib import admin
from .models import Fruits, FruitVarieties

admin.site.register(Fruits)
admin.site.register(FruitVarieties)