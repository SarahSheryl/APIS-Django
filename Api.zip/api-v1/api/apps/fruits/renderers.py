from api.apps.core.renderers import ApiJSONRenderer


class FruitsJSONRenderer(ApiJSONRenderer):
    object_label = 'fruits'
    pagination_object_label = 'fruits'
    pagination_count_label = 'fruits_count'

class FruitVarietiesJSONRenderer(ApiJSONRenderer):
    object_label = 'fruit_varieties'
    pagination_object_label = 'fruit varieties'
    pagination_count_label = 'fruit variety count'