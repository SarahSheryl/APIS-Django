from django.core.management.base import BaseCommand
from api.apps.authentication.models import User


class Command(BaseCommand):

    def handle(self, *args, **options):
        if not User.objects.filter(username="qzense").exists():
            User.objects.create_superuser("qzense", "qzenselabs@gmail.com", "Qzenselabs@2019")