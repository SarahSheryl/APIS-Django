from rest_framework.schemas import AutoSchema

import coreapi
import coreschema
import json

class RegistrationSchema(AutoSchema):

    def get_serializer_fields(self, path, method):
        return []

    def get_manual_fields(self, path, method):
        custom_fields = []
        if method.upper() == "POST":
            data =  {
                        "user": {
                            "username":"required", 
                            "email":"required", 
                            "warehouse": "required",
                            "password":"required"
                        }
                    }
            custom_fields = [
                coreapi.Field(
                    "user",
                    required=True,
                    location="body",
                    schema=coreschema.Object(description=
                        '<pre>'+json.dumps(data, indent=4)+'</pre>')
                ),
            ]
        return self._manual_fields + custom_fields

class LoginSchema(AutoSchema):

    def get_serializer_fields(self, path, method):
        return []

    def get_manual_fields(self, path, method):
        custom_fields = []
        if method.upper() == "POST":
            data = {
                        "user": {
                            "email": "required", 
                            "password": "required"
                        }
                    }
            custom_fields = [
                coreapi.Field(
                    "user",
                    required=True,
                    location="body",
                    schema=coreschema.Object(description=
                        '<pre>'+json.dumps(data, indent=4)+'</pre>')
                ),
            ]
        return self._manual_fields + custom_fields

class UserRetrieveUpdateSchema(AutoSchema):
    def get_serializer_fields(self, path, method):
        return []

    def get_manual_fields(self, path, method):
        custom_fields = []
        if method.upper() in ["PUT", "PATCH"]:
            data =  {
                        "user": {
                            "username": "optional",
                            "email": "optional", 
                            "password": "optional"
                        }
                    }
            custom_fields = [
                coreapi.Field(
                    "user",
                    required=True,
                    location="body",
                    schema=coreschema.Object(description=
                        '<pre>'+json.dumps(data, indent=4)+'</pre>')
                ),
            ]
        return self._manual_fields + custom_fields
