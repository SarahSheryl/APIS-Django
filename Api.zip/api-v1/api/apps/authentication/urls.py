from django.urls import path,include
"""
from .views import (
    LoginAPIView, RegistrationAPIView, UserRetrieveUpdateAPIView
)
"""
urlpatterns = [
  #  path('user/', UserRetrieveUpdateAPIView.as_view()),
  #  path('users/login/', LoginAPIView.as_view()),
  #  path('users/', RegistrationAPIView.as_view()),
    path('auth/',include('djoser.urls')),
    path('auth/',include('djoser.urls.jwt'))
]
