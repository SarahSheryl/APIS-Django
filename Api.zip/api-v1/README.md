# Qzense API

## Construction of API

- Qzense API is built using django rest framework
- Design and Construction of API points was strictly followed according to industry standards as outlined in the Django real world example
- Each table is a separate app inside the API, and similar tables are grouped into a single app (ex. Fruits and FruitVarieties)
- Authentication is performed using JWT (JSON web tokens)
- Qzense API provides CRUD (Create Read Update Delete) operations on tables(Not all tables have all CRUD operations)
- Qzense API provides the database schema which is used to create tables in the database

## Changes made over previous Database schema

### Fruit variety:

- fruit_variety table split into 2 tables, fruits and fruit_varieties with each entry in fruit_varieties containing a foreign key to a specific fruit
- Fruits given color field so that this color is displayed on charts for that specific fruit

### Warehouse user:

- warehouse_user table renamed to warehouses
warehouse_id field has now unique constraint which prevents duplicate warehouse_id creation

### Device setting:

- device_setting table renamed to devices
- Devices table contains a foreign key to warehouses table instead of duplicate warehouse_id text.
- device_id field has now unique constraint which prevents duplicate device_id creation

### Device types:

- Added device_types table for different types of device types
- Devices table contains a foreign key to a device_type


## API Endpoints for interaction

- All endpoints are documented on the deployed api under /docs

-API Docs: http://qzense-api.eba-iecajihv.ap-south-1.elasticbeanstalk.com/docs/

- API Docs are generated using rest_framework documentation

## Instructions on how to use API /docs to interact with API

- On the left panel, click on users, which will dropdown a sub-menu
- In the submenu click on login > create
- In the center, you should be able to see login > create
- Click on interact button
- In the user field enter the email and password in the format which is shows below the field.  
    Example.

    ```json
        {
            "user": {
                "email":"qzenselabs@gmail.com",
                "password":"Qzenselabs@2019"
            }
        }
    ```

- After you enter the user field, click on send request.
- In the response, you will get a token. Copy this token
- Click on close button
- In the bottom left corner, click on Authentication which will dropdown a submenu
- Click on Token
- In the Token field, paste the previously copied token
- In the Scheme field, enter “Token”
- You can now send requests which require you to be authenticated

## GitHub Repository

- Github repository of API is located at https://github.com/QzenseLabs/api

## Development

- Clone github repository on your computer
- Download .env file for api from google drive
- Place .env file in root of the project folder
- You need to have psql local development server running on your computer
- Set the psql server credentials in .env file
- Open terminal/command prompt
- Run  
`cd <project directory>`
- Create virtual environment with python
- Activate virtual environment
- Install requirements.txt with pip
- To start api, run  
`manage.py runserver`
- To make database schema changes, run  
`manage.py makemigrations`
- To push database schema changes run  
`manage.py migrate`
DB_NAME=qzense
DB_USER=postgres
DB_PASSWORD=21199
DB_HOST=127.0.0.1
DB_PORT=5432

## Admin User

- Admin user is automatically created when the API is deployed to beanstalk if admin user is not already present
- This is done through a custom django management command  
located in  
`api/apps/core/management/commands/createsu.py`


## Deployment
http://qzense-api.eba-iecajihv.ap-south-1.elasticbeanstalk.com/api/

- Run  
`cd <project directory>`
- Install elastic beanstalk CLI
- Sign in using AWS credentials (Placed in qzense_accessKeys on google drive)
- Mkdir .ebextensions in root folder of project
- Create django.config file inside .ebextensions
- Add path to wsgi application in  config as:

    ```yaml
    option_settings:
        aws:elasticbeanstalk:container:python:
        WSGIPath: api.wsgi:application
    ```

- Run `eb init -i` to initialize application
- Run `eb create <app-name>` to create application environment
- Change files and commit
- Run `eb deploy` to push changes to beanstalk

## Notes

Django python elastic beanstalk tutorial by AWS:
https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/create-deploy-python-django.html

Another tutorial:
https://realpython.com/deploying-a-django-app-and-postgresql-to-aws-elastic-beanstalk/

For static files troubleshooting:
https://stackoverflow.com/questions/62442212/aws-elastic-beanstalk-container-commands-failing
